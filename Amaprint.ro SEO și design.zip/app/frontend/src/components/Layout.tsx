import { Link, useLocation } from 'react-router-dom';
import { useState, useRef } from 'react';
import { Menu, X, Phone, Mail, MapPin, Clock, Facebook, Instagram, ChevronDown, ChevronRight, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { services, productCategories, SERVICE_AREAS } from '@/data/services';

interface NavChild {
  to: string;
  label: string;
  items?: { to: string; label: string }[];
}

interface NavLink {
  to: string;
  label: string;
  children?: NavChild[];
  megaMenu?: boolean;
}

const navLinks: NavLink[] = [
  { to: '/', label: 'Acasă' },
  {
    to: '/servicii',
    label: 'Servicii',
    children: services.map((s) => ({ to: `/servicii/${s.slug}`, label: s.title })),
  },
  {
    to: '/produse',
    label: 'Produse',
    megaMenu: true,
    children: productCategories.map((p) => ({
      to: `/produse/${p.slug}`,
      label: p.title,
      items: p.items.map((item) => ({
        to: `/produse/${p.slug}/${item.slug}`,
        label: item.name,
      })),
    })),
  },
  { to: '/blog', label: 'Blog' },
  { to: '/contact', label: 'Contact' },
];

function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/40799134444"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 group"
      aria-label="Contactează-ne pe WhatsApp"
    >
      <MessageCircle className="w-7 h-7 text-white" />
      <span className="absolute right-full mr-3 bg-white text-gray-800 text-sm font-medium px-3 py-2 rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap pointer-events-none">
        Scrie-ne pe WhatsApp
      </span>
      <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-ping" />
      <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full" />
    </a>
  );
}

function Navbar() {
  const [open, setOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [expandedMobileCategory, setExpandedMobileCategory] = useState<string | null>(null);
  const [expandedMobileSubCategory, setExpandedMobileSubCategory] = useState<string | null>(null);
  const location = useLocation();
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMouseEnter = (key: string) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setOpenDropdown(key);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setOpenDropdown(null), 150);
  };

  const toggleMobileCategory = (key: string) => {
    setExpandedMobileCategory((prev) => (prev === key ? null : key));
    setExpandedMobileSubCategory(null);
  };

  const toggleMobileSubCategory = (key: string) => {
    setExpandedMobileSubCategory((prev) => (prev === key ? null : key));
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      {/* Top bar */}
      <div className="bg-[#020381] text-white text-sm">
        <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4 flex-wrap">
            <a href="tel:0799134444" className="flex items-center gap-1 hover:text-[#30d2be] transition-colors">
              <Phone className="w-3.5 h-3.5" />
              <span>0799 134 444</span>
            </a>
            <a href="mailto:contact@amaprint.ro" className="flex items-center gap-1 hover:text-[#30d2be] transition-colors">
              <Mail className="w-3.5 h-3.5" />
              <span>contact@amaprint.ro</span>
            </a>
            <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-[#25D366] transition-colors">
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            <span>Dej · Gherla · Beclean · Cluj · Bistrița</span>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <nav className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group" aria-label="AMAprint - Pagina principală">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#30d2be] to-[#00d082] flex items-center justify-center text-white font-extrabold text-lg shadow-md group-hover:scale-105 transition-transform">
            A
          </div>
          <div>
            <span className="text-xl font-bold text-[#020381]">AMA</span>
            <span className="text-xl font-bold text-[#30d2be]">print</span>
          </div>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <div
              key={link.to}
              className="relative"
              onMouseEnter={() => link.children && handleMouseEnter(link.to)}
              onMouseLeave={handleMouseLeave}
            >
              <Link
                to={link.to}
                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center gap-1 ${
                  location.pathname === link.to || (link.to !== '/' && location.pathname.startsWith(link.to + '/'))
                    ? 'text-[#020381] bg-[#30d2be]/10'
                    : 'text-gray-600 hover:text-[#020381] hover:bg-gray-50'
                }`}
              >
                {link.label}
                {link.children && <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${openDropdown === link.to ? 'rotate-180' : ''}`} />}
              </Link>

              {/* Regular dropdown (Servicii) */}
              {link.children && !link.megaMenu && openDropdown === link.to && (
                <div className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 py-2 min-w-[220px] z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <Link
                    to={link.to}
                    className="block px-4 py-2.5 text-sm font-semibold text-[#020381] hover:bg-[#30d2be]/10 transition-colors"
                  >
                    Toate {link.label}
                  </Link>
                  <div className="border-t border-gray-100 my-1" />
                  {link.children.map((child) => (
                    <Link
                      key={child.to}
                      to={child.to}
                      className="block px-4 py-2 text-sm text-gray-600 hover:text-[#020381] hover:bg-gray-50 transition-colors"
                    >
                      {child.label}
                    </Link>
                  ))}
                </div>
              )}

              {/* Mega menu (Produse) */}
              {link.megaMenu && link.children && openDropdown === link.to && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 animate-in fade-in slide-in-from-top-2 duration-150 w-[700px]">
                  {/* Header */}
                  <div className="px-6 pt-4 pb-3 border-b border-gray-100">
                    <Link
                      to={link.to}
                      className="text-sm font-bold text-[#020381] hover:text-[#30d2be] transition-colors"
                    >
                      Toate Produsele →
                    </Link>
                  </div>
                  {/* Categories grid */}
                  <div className="grid grid-cols-2 gap-0 p-4">
                    {link.children.map((category) => (
                      <div key={category.to} className="p-3">
                        <Link
                          to={category.to}
                          className="flex items-center gap-2 text-sm font-bold text-[#020381] hover:text-[#30d2be] transition-colors mb-2 pb-2 border-b border-gray-100"
                        >
                          <span className="w-2 h-2 rounded-full bg-gradient-to-r from-[#30d2be] to-[#00d082] flex-shrink-0" />
                          {category.label}
                          <ChevronRight className="w-3.5 h-3.5 ml-auto opacity-50" />
                        </Link>
                        {category.items && (
                          <ul className="space-y-0.5">
                            {category.items.map((item) => (
                              <li key={item.to}>
                                <Link
                                  to={item.to}
                                  className="block px-3 py-1.5 text-sm text-gray-500 hover:text-[#020381] hover:bg-[#30d2be]/5 rounded-md transition-colors"
                                >
                                  {item.label}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    ))}
                  </div>
                  {/* Footer CTA */}
                  <div className="px-6 py-3 bg-gray-50 rounded-b-xl border-t border-gray-100 flex items-center justify-between">
                    <span className="text-xs text-gray-400">📍 Disponibil în Dej, Gherla, Beclean, Cluj, Bistrița</span>
                    <Link to="/contact" className="text-xs font-semibold text-[#30d2be] hover:text-[#020381] transition-colors">
                      Solicită Ofertă →
                    </Link>
                  </div>
                </div>
              )}
            </div>
          ))}
          <Link to="/contact">
            <Button className="ml-3 bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90 shadow-md hover:shadow-lg transition-all">
              Cere Ofertă
            </Button>
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden border-t border-gray-100 bg-white animate-in slide-in-from-top-2 duration-200 max-h-[75vh] overflow-y-auto">
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <div key={link.to}>
                {/* Top-level link */}
                {link.children ? (
                  <button
                    onClick={() => toggleMobileCategory(link.to)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-semibold transition-colors ${
                      location.pathname.startsWith(link.to)
                        ? 'text-[#020381] bg-[#30d2be]/10'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <span>{link.label}</span>
                    <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${expandedMobileCategory === link.to ? 'rotate-180' : ''}`} />
                  </button>
                ) : (
                  <Link
                    to={link.to}
                    onClick={() => setOpen(false)}
                    className={`block px-4 py-3 rounded-lg text-sm font-semibold transition-colors ${
                      location.pathname === link.to
                        ? 'text-[#020381] bg-[#30d2be]/10'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {link.label}
                  </Link>
                )}

                {/* Expanded children */}
                {link.children && expandedMobileCategory === link.to && (
                  <div className="ml-2 mt-1 space-y-0.5 border-l-2 border-[#30d2be]/20 pl-2">
                    {/* "Toate" link */}
                    <Link
                      to={link.to}
                      onClick={() => setOpen(false)}
                      className="block px-3 py-2 text-sm font-semibold text-[#020381] hover:bg-[#30d2be]/10 rounded-lg transition-colors"
                    >
                      Toate {link.label} →
                    </Link>

                    {link.children.map((child) => (
                      <div key={child.to}>
                        {/* Category with sub-items (mega menu items) */}
                        {child.items && child.items.length > 0 ? (
                          <>
                            <button
                              onClick={() => toggleMobileSubCategory(child.to)}
                              className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#020381] hover:bg-gray-50 rounded-lg transition-colors"
                            >
                              <span>{child.label}</span>
                              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${expandedMobileSubCategory === child.to ? 'rotate-180' : ''}`} />
                            </button>
                            {expandedMobileSubCategory === child.to && (
                              <div className="ml-3 mt-0.5 space-y-0.5 border-l-2 border-gray-100 pl-2">
                                <Link
                                  to={child.to}
                                  onClick={() => setOpen(false)}
                                  className="block px-3 py-1.5 text-xs font-semibold text-[#30d2be] hover:bg-[#30d2be]/10 rounded-md transition-colors"
                                >
                                  Toate din {child.label} →
                                </Link>
                                {child.items.map((item) => (
                                  <Link
                                    key={item.to}
                                    to={item.to}
                                    onClick={() => setOpen(false)}
                                    className="block px-3 py-1.5 text-sm text-gray-500 hover:text-[#020381] hover:bg-gray-50 rounded-md transition-colors"
                                  >
                                    {item.label}
                                  </Link>
                                ))}
                              </div>
                            )}
                          </>
                        ) : (
                          /* Simple child link (services) */
                          <Link
                            to={child.to}
                            onClick={() => setOpen(false)}
                            className="block px-3 py-2 text-sm text-gray-500 hover:text-[#020381] hover:bg-gray-50 rounded-lg transition-colors"
                          >
                            {child.label}
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <Link to="/contact" onClick={() => setOpen(false)}>
              <Button className="w-full mt-2 bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold">
                Cere Ofertă
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="bg-[#0a0a1a] text-gray-300">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#30d2be] to-[#00d082] flex items-center justify-center text-white font-extrabold text-base">
                A
              </div>
              <div>
                <span className="text-lg font-bold text-white">AMA</span>
                <span className="text-lg font-bold text-[#30d2be]">print</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-gray-400">
              Tipografie cu experiență în Dej, specializată în servicii de tipar digital, offset, serigrafie și broderie. Partenerul tău de încredere pentru materiale de calitate.
            </p>
            <div className="mt-4 flex items-center gap-2 text-sm text-gray-400">
              <MapPin className="w-4 h-4 text-[#30d2be]" />
              <span>Deservim: {SERVICE_AREAS.join(', ')}</span>
            </div>
            <div className="flex gap-3 mt-5">
              <a href="https://www.facebook.com/amamedia.ro" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#30d2be] transition-colors" aria-label="Facebook AMAprint">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://www.instagram.com/amamediadesign/" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#30d2be] transition-colors" aria-label="Instagram AMAprint">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#25D366] transition-colors" aria-label="WhatsApp AMAprint">
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Servicii */}
          <div>
            <h3 className="text-white font-semibold text-base mb-4">Servicii</h3>
            <ul className="space-y-2 text-sm">
              {services.map((s) => (
                <li key={s.slug}>
                  <Link to={`/servicii/${s.slug}`} className="hover:text-[#30d2be] transition-colors">{s.title}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Produse & Legal */}
          <div>
            <h3 className="text-white font-semibold text-base mb-4">Produse</h3>
            <ul className="space-y-2 text-sm">
              {productCategories.map((p) => (
                <li key={p.slug}>
                  <Link to={`/produse/${p.slug}`} className="hover:text-[#30d2be] transition-colors">{p.title}</Link>
                </li>
              ))}
            </ul>
            <h3 className="text-white font-semibold text-base mb-3 mt-6">Resurse</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/blog" className="hover:text-[#30d2be] transition-colors">Blog</Link></li>
              <li><Link to="/gdpr" className="hover:text-[#30d2be] transition-colors">Politica GDPR</Link></li>
              <li><Link to="/termeni" className="hover:text-[#30d2be] transition-colors">Termeni și Condiții</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold text-base mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 text-[#30d2be] shrink-0" />
                <a href="https://maps.google.com/?q=amamedia+dej" target="_blank" rel="noopener noreferrer" className="hover:text-[#30d2be] transition-colors">Str. Florilor 18, Dej, Jud. Cluj</a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#30d2be] shrink-0" />
                <a href="tel:0799134444" className="hover:text-[#30d2be] transition-colors">0799 134 444</a>
              </li>
              <li className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer" className="hover:text-[#25D366] transition-colors">WhatsApp: 0799 13 44 44</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#30d2be] shrink-0" />
                <a href="mailto:contact@amaprint.ro" className="hover:text-[#30d2be] transition-colors">contact@amaprint.ro</a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 mt-0.5 text-[#30d2be] shrink-0" />
                <div>
                  <p>Luni - Vineri: 8:00 - 17:00</p>
                  <p>Weekend: Închis</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} AMAprint - AMADESIGN SRL. Toate drepturile rezervate.</p>
          <div className="flex gap-4">
            <Link to="/gdpr" className="hover:text-[#30d2be] transition-colors">GDPR</Link>
            <Link to="/termeni" className="hover:text-[#30d2be] transition-colors">Termeni</Link>
            <a href="https://anpc.ro" target="_blank" rel="noopener noreferrer" className="hover:text-[#30d2be] transition-colors">ANPC</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}