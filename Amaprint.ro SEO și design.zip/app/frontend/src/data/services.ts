import {
  Printer,
  Copy,
  ScanLine,
  Layers,
  Zap,
  Shirt,
  Scissors,
  Stamp,
  PenTool,
  type LucideIcon,
} from 'lucide-react';

const LASER_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/899268/2026-03-10/f9efb908-b2ad-44fc-aaf0-9022fcaa7467.png';
const TEXTILE_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/899268/2026-03-10/ce9cf5e2-c40d-420c-9481-7a9ad2a424bf.png';
const HERO_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/899268/2026-03-10/e5c56874-2885-4026-94fc-e1f49f9ae8f9.png';
const PRODUCTS_IMG = 'https://mgx-backend-cdn.metadl.com/generate/images/899268/2026-03-10/216cd269-5afb-445e-a12a-0d995015d217.png';

export { LASER_IMG, TEXTILE_IMG, HERO_IMG, PRODUCTS_IMG };

export const SERVICE_AREAS = ['Dej', 'Gherla', 'Beclean', 'Cluj', 'Bistrița'];

export interface ServiceData {
  slug: string;
  icon: LucideIcon;
  title: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  benefits: string[];
  image?: string;
  metaTitle: string;
  metaDesc: string;
}

export const services: ServiceData[] = [
  {
    slug: 'listare',
    icon: Printer,
    title: 'Listare',
    shortDesc: 'Materiale publicitare și documente corporative cu echipamente moderne.',
    fullDesc: 'Cu echipamente moderne și o experiență vastă în domeniu, Amaprint poate satisface nevoile clienților pentru materiale publicitare, documente corporative sau alte proiecte personalizate. Oferim listare alb-negru și color, pe diferite formate și tipuri de hârtie, de la A5 la A0. Fie că aveți nevoie de câteva copii sau de tiraje mari, suntem pregătiți să livrăm rapid și la cele mai înalte standarde de calitate.',
    features: ['Listare A4/A3/A0', 'Alb-negru și color', 'Hârtie premium', 'Volume mari', 'Livrare rapidă', 'Prețuri competitive'],
    benefits: ['Echipamente de ultimă generație', 'Calitate superioară a imprimării', 'Timp de execuție redus', 'Consultanță gratuită'],
    image: HERO_IMG,
    metaTitle: 'Listare și Printare Profesională Dej | AMAprint - Tipografie Dej și Împrejurimi',
    metaDesc: 'Servicii de listare profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Listare alb-negru și color pe diverse formate. Echipamente moderne, calitate superioară. AMAprint Dej.',
  },
  {
    slug: 'copiere',
    icon: Copy,
    title: 'Copiere',
    shortDesc: 'Reproducerea materialelor cu acuratețe și fidelitate maximă.',
    fullDesc: 'De la documente standard la proiecte mai complexe, clienții pot avea încredere în capacitatea noastră de a reproduce materialele lor cu acuratețe și fidelitate. Copiere rapidă la cele mai înalte standarde de calitate. Oferim copiere alb-negru și color, pe formate de la A5 la A0, cu posibilitatea de mărire sau micșorare a documentelor originale.',
    features: ['Copiere rapidă', 'Fidelitate maximă', 'Formate diverse', 'Volum mare', 'Mărire/Micșorare', 'Color și alb-negru'],
    benefits: ['Reproducere fidelă a originalului', 'Viteză mare de copiere', 'Costuri reduse pentru volume mari', 'Disponibilitate imediată'],
    metaTitle: 'Copiere Documente Profesională Dej | AMAprint - Tipografie Dej și Împrejurimi',
    metaDesc: 'Copiere documente profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Copiere rapidă alb-negru și color. Fidelitate maximă. AMAprint Dej.',
  },
  {
    slug: 'scanare',
    icon: ScanLine,
    title: 'Scanare',
    shortDesc: 'Digitalizarea și conservarea documentelor importante.',
    fullDesc: 'Scanarea documentelor este esențială pentru conservarea și digitalizarea informațiilor. Oferim servicii de scanare profesională pentru documente, fotografii și materiale de orice dimensiune. Scanăm la rezoluții înalte pentru a asigura calitatea optimă a fișierelor digitale. Oferim și servicii OCR pentru transformarea documentelor scanate în text editabil.',
    features: ['Rezoluție înaltă', 'Formate digitale multiple', 'OCR disponibil', 'Arhivare digitală', 'Scanare color', 'Formate mari'],
    benefits: ['Conservarea documentelor importante', 'Acces digital rapid', 'Reducerea spațiului de stocare fizic', 'Partajare ușoară a documentelor'],
    metaTitle: 'Scanare Documente Profesională Dej | AMAprint - Tipografie Dej și Împrejurimi',
    metaDesc: 'Scanare profesională documente în Dej, Gherla, Beclean, Cluj și Bistrița. Rezoluție înaltă, OCR, formate digitale. Digitalizare și arhivare. AMAprint Dej.',
  },
  {
    slug: 'laminare',
    icon: Layers,
    title: 'Laminare',
    shortDesc: 'Protecție și aspect îmbunătățit pentru documente și afișe.',
    fullDesc: 'Amaprint oferă servicii de laminare pentru a proteja și a îmbunătăți aspectul documentelor, afișelor sau altor materiale. Laminarea prelungește durata de viață a materialelor și le oferă un aspect profesional. Oferim laminare mată și lucioasă, în diverse grosimi, pentru formate de la A5 la A0.',
    features: ['Laminare mată/lucioasă', 'Protecție UV', 'Formate diverse', 'Durabilitate crescută', 'Grosimi variate', 'Finisaj profesional'],
    benefits: ['Protecție împotriva umezelii și murdăriei', 'Aspect profesional și elegant', 'Durabilitate crescută a materialelor', 'Rezistență la uzură'],
    metaTitle: 'Laminare Documente Profesională Dej | AMAprint - Tipografie Dej și Împrejurimi',
    metaDesc: 'Laminare profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Laminare mată și lucioasă, protecție UV. Durabilitate și aspect profesional. AMAprint Dej.',
  },
  {
    slug: 'gravura-laser',
    icon: Zap,
    title: 'Gravură Laser',
    shortDesc: 'Detalii fine și precise pe lemn, sticlă, metal și plastic.',
    fullDesc: 'Cu tehnologia noastră de gravură laser, putem crea detalii fine și precise pe o varietate de materiale, de la lemn și sticlă la metal și plastic. Ideală pentru cadouri personalizate, plăci, trofee și obiecte decorative. Gravura laser oferă o precizie excepțională și rezultate durabile, fără a deteriora materialul de bază.',
    features: ['Lemn & Sticlă', 'Metal & Plastic', 'Precizie maximă', 'Personalizare unică', 'Trofee & Plăci', 'Obiecte decorative'],
    benefits: ['Precizie excepțională a detaliilor', 'Durabilitate permanentă a gravurii', 'Versatilitate pe multiple materiale', 'Cadouri unice și memorabile'],
    image: LASER_IMG,
    metaTitle: 'Gravură Laser Profesională Dej | AMAprint - Gravură Laser Dej și Împrejurimi',
    metaDesc: 'Gravură laser profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Gravură pe lemn, sticlă, metal, plastic. Cadouri personalizate, trofee. AMAprint Dej.',
  },
  {
    slug: 'imprimare-textila',
    icon: Shirt,
    title: 'Imprimare Textilă',
    shortDesc: 'Personalizarea tricourilor, echipamentelor și uniformelor.',
    fullDesc: 'Imprimarea textilă oferită de Amaprint este o soluție perfectă pentru personalizarea tricourilor, echipamentelor sportive, uniformelor și altor articole textile. Folosim tehnologii moderne de transfer termic și sublimare pentru rezultate durabile care rezistă la spălări repetate. Ideală pentru echipe, evenimente, campanii promoționale sau cadouri personalizate.',
    features: ['Tricouri', 'Echipamente sportive', 'Uniforme', 'Durabilitate la spălare', 'Transfer termic', 'Sublimare'],
    benefits: ['Culori vibrante și durabile', 'Rezistență la spălări repetate', 'Personalizare completă', 'Tiraje mici și mari'],
    image: TEXTILE_IMG,
    metaTitle: 'Imprimare Textilă Profesională Dej | AMAprint - Print Textile Dej și Împrejurimi',
    metaDesc: 'Imprimare textilă profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Personalizare tricouri, uniforme, echipamente sportive. AMAprint Dej.',
  },
  {
    slug: 'broderie',
    icon: Scissors,
    title: 'Broderie',
    shortDesc: 'Eleganță și rafinament pentru produse textile personalizate.',
    fullDesc: 'Broderia adaugă un plus de eleganță și rafinament produselor textile personalizate. Oferim broderie computerizată de înaltă calitate pe diverse materiale textile. Broderia este ideală pentru logo-uri, texte personalizate, uniforme corporate și cadouri de lux. Rezultatele sunt durabile și rezistente la spălare.',
    features: ['Broderie computerizată', 'Logo-uri', 'Texte personalizate', 'Materiale diverse', 'Uniforme corporate', 'Cadouri de lux'],
    benefits: ['Aspect premium și elegant', 'Durabilitate excepțională', 'Detalii fine și precise', 'Personalizare completă'],
    metaTitle: 'Broderie Computerizată Profesională Dej | AMAprint - Broderie Dej și Împrejurimi',
    metaDesc: 'Broderie computerizată profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Logo-uri, texte personalizate, uniforme. Calitate premium. AMAprint Dej.',
  },
  {
    slug: 'serigrafie',
    icon: PenTool,
    title: 'Serigrafie',
    shortDesc: 'Imprimarea în detaliu a elementelor grafice pe obiecte promoționale.',
    fullDesc: 'Metode de personalizare obiecte promoționale ideale pentru imprimarea în detaliu a diverselor elemente grafice. Serigrafie profesională pentru tiraje mari și mici. Serigrafie pe textile, ceramică, plastic, metal și alte materiale. Culorile sunt vibrante și durabile, ideale pentru produse promoționale de calitate.',
    features: ['Obiecte promoționale', 'Tiraje mari', 'Culori vibrante', 'Durabilitate', 'Materiale diverse', 'Detalii fine'],
    benefits: ['Culori intense și rezistente', 'Cost eficient pentru tiraje mari', 'Versatilitate pe multiple materiale', 'Rezultate profesionale'],
    metaTitle: 'Serigrafie Profesională Dej | AMAprint - Serigrafie Dej și Împrejurimi',
    metaDesc: 'Serigrafie profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Personalizare obiecte promoționale, textile, ceramică. Culori vibrante. AMAprint Dej.',
  },
  {
    slug: 'stampile',
    icon: Stamp,
    title: 'Stampile',
    shortDesc: 'Stampile și accesorii de diferite forme și dimensiuni.',
    fullDesc: 'Stampile și accesorii, datiere, inseriatoare de diferite forme și dimensiuni vă stau la dispoziție împreună cu toate accesoriile și consumabilele necesare. Oferim stampile automate, cu tuș incorporat, stampile de buzunar, stampile rotunde, dreptunghiulare și cu forme personalizate. Livrare rapidă și prețuri competitive.',
    features: ['Stampile personalizate', 'Datiere', 'Inseriatoare', 'Accesorii & Consumabile', 'Stampile automate', 'Forme diverse'],
    benefits: ['Personalizare completă', 'Tuș de calitate superioară', 'Durabilitate în utilizare', 'Livrare rapidă'],
    metaTitle: 'Stampile Personalizate Dej | AMAprint - Stampile Dej și Împrejurimi',
    metaDesc: 'Stampile personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Stampile automate, datiere, inseriatoare. Forme diverse. Livrare rapidă. AMAprint Dej.',
  },
];

export interface ProductItem {
  slug: string;
  name: string;
  desc: string;
  fullDesc: string;
  features: string[];
  benefits: string[];
  metaTitle: string;
  metaDesc: string;
}

export interface ProductCategory {
  slug: string;
  icon: LucideIcon;
  title: string;
  desc: string;
  items: ProductItem[];
  gradient: string;
  metaTitle: string;
  metaDesc: string;
}

export const productCategories: ProductCategory[] = [
  {
    slug: 'tipografie',
    icon: Printer,
    title: 'Tipografie',
    desc: 'Materiale tipografice profesionale pentru afacerea ta. De la cărți de vizită la afișe de mari dimensiuni.',
    items: [
      {
        slug: 'afise',
        name: 'Afișe',
        desc: 'Promovați-vă evenimentele și ofertele cu afișe de înaltă calitate, personalizate și atrăgătoare.',
        fullDesc: 'Afișele sunt unul dintre cele mai eficiente instrumente de promovare vizuală. La AMAprint Dej, realizăm afișe de înaltă calitate pe diverse formate, de la A3 la A0 și chiar mai mari. Folosim hârtie premium și echipamente de ultimă generație pentru a asigura culori vibrante și detalii clare. Fie că aveți nevoie de afișe pentru evenimente, oferte speciale, campanii publicitare sau decorațiuni interioare, suntem pregătiți să livrăm rapid și la cele mai înalte standarde.',
        features: ['Formate A3, A2, A1, A0', 'Hârtie premium glossy/mată', 'Culori vibrante și rezistente', 'Tiraje mici și mari', 'Design grafic inclus', 'Livrare rapidă'],
        benefits: ['Impact vizual puternic', 'Cost eficient per unitate', 'Personalizare completă', 'Consultanță gratuită pentru design'],
        metaTitle: 'Afișe Personalizate Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Afișe personalizate de înaltă calitate în Dej, Gherla, Beclean, Cluj și Bistrița. Formate diverse, hârtie premium, culori vibrante. AMAprint Dej.',
      },
      {
        slug: 'etichete',
        name: 'Etichete',
        desc: 'Etichetele personalizate sunt esențiale pentru identitatea și branding-ul produselor dvs.',
        fullDesc: 'Etichetele personalizate sunt esențiale pentru identitatea produselor și branding-ul companiei. AMAprint Dej oferă etichete autoadezive, etichete pe hârtie, etichete transparente și etichete rezistente la apă. Realizăm etichete pentru produse alimentare, cosmetice, industriale, băuturi și multe altele. Disponibile în forme standard sau personalizate, cu finisaje speciale precum lăcuire UV sau folio.',
        features: ['Etichete autoadezive', 'Forme personalizate', 'Rezistente la apă', 'Lăcuire UV selectivă', 'Folio auriu/argintiu', 'Tiraje de la 100 buc'],
        benefits: ['Branding profesional al produselor', 'Materiale de calitate superioară', 'Forme și dimensiuni la comandă', 'Livrare rapidă în zona Dej'],
        metaTitle: 'Etichete Personalizate Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Etichete personalizate autoadezive în Dej, Gherla, Beclean, Cluj și Bistrița. Etichete pentru produse, rezistente la apă, forme custom. AMAprint Dej.',
      },
      {
        slug: 'carti-de-vizita',
        name: 'Cărți de Vizită',
        desc: 'Cărțile de vizită sunt cartea dvs. de vizită în lumea afacerilor. Oferiți o primă impresie de neuitat.',
        fullDesc: 'Cărțile de vizită rămân un instrument esențial de networking și branding. La AMAprint Dej, realizăm cărți de vizită pe hârtie premium de 300-400g, cu diverse finisaje: laminare mată sau lucioasă, lăcuire UV selectivă, folio auriu sau argintiu, colțuri rotunjite și forme personalizate. Oferim și cărți de vizită cu cod QR integrat pentru o experiență digitală completă. De la design la livrare, suntem alături de afacerea ta.',
        features: ['Hârtie premium 300-400g', 'Laminare mată/lucioasă', 'Lăcuire UV selectivă', 'Folio auriu/argintiu', 'Cod QR integrat', 'Design grafic inclus'],
        benefits: ['Prima impresie profesională', 'Calitate premium la prețuri competitive', 'Livrare rapidă în 24-48h', 'Consultanță gratuită pentru design'],
        metaTitle: 'Cărți de Vizită Premium Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Cărți de vizită premium în Dej, Gherla, Beclean, Cluj și Bistrița. Hârtie 300-400g, laminare, folio, lăcuire UV. Design inclus. AMAprint Dej.',
      },
      {
        slug: 'meniuri',
        name: 'Meniuri',
        desc: 'Meniuri profesionale pentru restaurante și localuri, cu design atractiv și materiale durabile.',
        fullDesc: 'Meniurile profesionale sunt esențiale pentru restaurante, cafenele, baruri și hoteluri. AMAprint Dej realizează meniuri pe hârtie premium, laminate pentru durabilitate, cu design atractiv care reflectă identitatea localului. Oferim meniuri pliate, meniuri de masă, meniuri de perete, meniuri digitale printate și meniuri speciale pentru evenimente. Materialele sunt rezistente la umezeală și uzură zilnică.',
        features: ['Hârtie premium laminată', 'Rezistentă la umezeală', 'Design personalizat', 'Meniuri pliate/de masă', 'Meniuri de perete', 'Actualizare ușoară'],
        benefits: ['Aspect profesional pentru localul tău', 'Durabilitate în utilizare zilnică', 'Design atractiv care vinde', 'Prețuri competitive pentru HoReCa'],
        metaTitle: 'Meniuri Restaurante Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Meniuri profesionale pentru restaurante în Dej, Gherla, Beclean, Cluj și Bistrița. Laminate, rezistente, design atractiv. AMAprint Dej.',
      },
      {
        slug: 'mape-cu-buzunar',
        name: 'Mape cu Buzunar',
        desc: 'Organizați documentele și prezentările cu mape de calitate, practice și profesionale.',
        fullDesc: 'Mapele cu buzunar sunt instrumente esențiale pentru prezentări profesionale și organizarea documentelor. AMAprint Dej produce mape personalizate cu logo-ul companiei, pe carton de calitate superioară, cu unul sau două buzunare interioare. Ideale pentru oferte comerciale, prezentări de companie, dosare de presă și materiale de conferință. Disponibile cu diverse finisaje: laminare, lăcuire UV, folio.',
        features: ['Carton premium 300-350g', '1 sau 2 buzunare', 'Logo personalizat', 'Laminare mată/lucioasă', 'Slot pentru carte de vizită', 'Forme standard și custom'],
        benefits: ['Prezentare profesională a documentelor', 'Consolidarea identității de brand', 'Organizare eficientă', 'Impact pozitiv asupra clienților'],
        metaTitle: 'Mape cu Buzunar Personalizate Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Mape cu buzunar personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Carton premium, logo, laminare. Prezentări profesionale. AMAprint Dej.',
      },
      {
        slug: 'flyere-pliante',
        name: 'Flyere & Pliante',
        desc: 'Materiale promoționale eficiente pentru campanii de marketing și evenimente.',
        fullDesc: 'Flyerele și pliantele sunt cele mai populare materiale promoționale, eficiente și accesibile. AMAprint Dej realizează flyere și pliante pe hârtie de calitate, în diverse formate (A4, A5, A6, DL) și tipuri de pliere (2 fețe, 3 fețe, acordeon, poartă). Culorile sunt vibrante, iar finisajele disponibile includ laminare mată sau lucioasă. Ideale pentru campanii de marketing, evenimente, meniuri pliante și cataloage mici.',
        features: ['Formate A4, A5, A6, DL', 'Pliere 2/3/4 fețe', 'Hârtie 130-300g', 'Laminare opțională', 'Culori vibrante', 'Tiraje de la 100 buc'],
        benefits: ['Cost redus per unitate', 'Distribuție ușoară', 'Impact vizual ridicat', 'Versatilitate în utilizare'],
        metaTitle: 'Flyere și Pliante Dej | AMAprint - Tipografie Dej și Împrejurimi',
        metaDesc: 'Flyere și pliante personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Formate diverse, hârtie premium, culori vibrante. AMAprint Dej.',
      },
    ],
    gradient: 'from-[#020381] to-[#2575fc]',
    metaTitle: 'Produse Tipografie Profesională Dej | AMAprint - Tipografie Dej și Împrejurimi',
    metaDesc: 'Produse tipografice profesionale în Dej, Gherla, Beclean, Cluj și Bistrița: afișe, cărți de vizită, flyere, pliante, etichete, meniuri. AMAprint Dej.',
  },
  {
    slug: 'promotionale',
    icon: Printer,
    title: 'Produse Promoționale',
    desc: 'Obiecte promoționale personalizate cu logo-ul și brandul tău pentru campanii de marketing eficiente.',
    items: [
      {
        slug: 'pixuri',
        name: 'Pixuri',
        desc: 'Pixuri personalizate cu logo-ul companiei, ideale pentru cadouri promoționale.',
        fullDesc: 'Pixurile personalizate sunt cele mai populare și accesibile obiecte promoționale. AMAprint Dej oferă o gamă largă de pixuri personalizabile prin imprimare sau gravură laser. De la pixuri economice pentru distribuție în masă, la pixuri premium metalice pentru cadouri corporate de lux. Fiecare pix poate fi personalizat cu logo, text, website sau număr de telefon.',
        features: ['Pixuri plastic economice', 'Pixuri metalice premium', 'Gravură laser', 'Imprimare color', 'Cutii cadou opționale', 'Minim 50 bucăți'],
        benefits: ['Cel mai popular obiect promoțional', 'Cost redus per unitate', 'Utilizare zilnică = vizibilitate maximă', 'Gamă variată de modele'],
        metaTitle: 'Pixuri Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Pixuri personalizate cu logo în Dej, Gherla, Beclean, Cluj și Bistrița. Gravură laser, imprimare color, pixuri premium. AMAprint Dej.',
      },
      {
        slug: 'brichete',
        name: 'Brichete',
        desc: 'Brichete personalizate, un cadou promoțional practic și apreciat.',
        fullDesc: 'Brichetele personalizate sunt cadouri promoționale practice și apreciate. AMAprint Dej oferă brichete personalizate prin imprimare color sau gravură laser. Disponibile în diverse modele: brichete clasice, brichete metalice, brichete cu capac și brichete electronice. Ideale pentru restaurante, baruri, hoteluri, evenimente și campanii promoționale.',
        features: ['Brichete clasice și metalice', 'Imprimare color full', 'Gravură laser', 'Diverse modele', 'Brichete electronice', 'Minim 100 bucăți'],
        benefits: ['Cadou practic și apreciat', 'Vizibilitate constantă a brandului', 'Cost redus per unitate', 'Ideal pentru HoReCa'],
        metaTitle: 'Brichete Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Brichete personalizate cu logo în Dej, Gherla, Beclean, Cluj și Bistrița. Imprimare color, gravură laser, modele diverse. AMAprint Dej.',
      },
      {
        slug: 'agende',
        name: 'Agende',
        desc: 'Agende personalizate pentru un branding profesional și util.',
        fullDesc: 'Agendele personalizate sunt cadouri corporate de valoare care oferă vizibilitate brandului pe tot parcursul anului. AMAprint Dej realizează agende personalizate cu copertă tare sau moale, cu logo gravat sau imprimat, în diverse formate (A4, A5, B5). Oferim agende datate și nedatate, cu inserturi personalizate, buzunare interioare și elastic de închidere. Ideale pentru cadouri de Crăciun, conferințe și evenimente corporate.',
        features: ['Copertă tare/moale', 'Logo gravat/imprimat', 'Formate A4, A5, B5', 'Datate și nedatate', 'Inserturi personalizate', 'Elastic de închidere'],
        benefits: ['Vizibilitate pe tot anul', 'Cadou corporate apreciat', 'Branding profesional', 'Utilitate zilnică'],
        metaTitle: 'Agende Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Agende personalizate cu logo în Dej, Gherla, Beclean, Cluj și Bistrița. Copertă tare, gravură, formate diverse. AMAprint Dej.',
      },
      {
        slug: 'calendare',
        name: 'Calendare',
        desc: 'Calendare de perete sau birou, personalizate cu imaginea companiei.',
        fullDesc: 'Calendarele personalizate sunt instrumente de marketing eficiente care oferă vizibilitate brandului 365 de zile pe an. AMAprint Dej realizează calendare de perete (1 filă, 7 file, 12 file), calendare de birou, calendare magnetice și calendare de buzunar. Fiecare calendar poate fi personalizat cu fotografii, logo, mesaje și date importante ale companiei.',
        features: ['Calendare de perete 1/7/12 file', 'Calendare de birou', 'Calendare magnetice', 'Calendare de buzunar', 'Fotografii personalizate', 'Date importante marcate'],
        benefits: ['Vizibilitate 365 zile/an', 'Cost eficient per impresie', 'Cadou util și apreciat', 'Personalizare completă'],
        metaTitle: 'Calendare Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Calendare personalizate de perete și birou în Dej, Gherla, Beclean, Cluj și Bistrița. Logo, fotografii, formate diverse. AMAprint Dej.',
      },
      {
        slug: 'cani-promotionale',
        name: 'Căni',
        desc: 'Căni personalizate cu logo sau mesaje, perfecte pentru cadouri corporate.',
        fullDesc: 'Cănile personalizate sunt cadouri promoționale populare și utile. AMAprint Dej oferă căni ceramice, căni termice, căni de călătorie și căni magice (care își schimbă culoarea la căldură). Personalizarea se face prin sublimare pentru imagini foto-realiste sau prin gravură laser pentru un aspect premium. Ideale pentru cadouri corporate, evenimente, campanii promoționale sau cadouri personalizate.',
        features: ['Căni ceramice clasice', 'Căni termice', 'Căni magice', 'Sublimare foto', 'Gravură laser', 'Cutii cadou opționale'],
        benefits: ['Cadou util și apreciat', 'Imagini foto-realiste', 'Durabilitate la spălare', 'Diverse modele disponibile'],
        metaTitle: 'Căni Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Căni personalizate cu logo și fotografii în Dej, Gherla, Beclean, Cluj și Bistrița. Sublimare, gravură laser, căni termice. AMAprint Dej.',
      },
      {
        slug: 'pungi',
        name: 'Pungi',
        desc: 'Pungi personalizate din diverse materiale, pentru un branding eco-friendly.',
        fullDesc: 'Pungile personalizate sunt esențiale pentru branding-ul afacerii tale. AMAprint Dej oferă pungi din hârtie kraft, pungi din material textil (bumbac, poliester), pungi din plastic biodegradabil și pungi din carton. Fiecare pungă poate fi personalizată cu logo, mesaje și design grafic. Ideale pentru magazine, evenimente, târguri și cadouri corporate.',
        features: ['Pungi hârtie kraft', 'Pungi textile bumbac', 'Pungi carton premium', 'Pungi biodegradabile', 'Logo și design custom', 'Diverse dimensiuni'],
        benefits: ['Branding eco-friendly', 'Reutilizabile și durabile', 'Impact pozitiv asupra imaginii', 'Personalizare completă'],
        metaTitle: 'Pungi Personalizate Dej | AMAprint - Produse Promoționale Dej și Împrejurimi',
        metaDesc: 'Pungi personalizate cu logo în Dej, Gherla, Beclean, Cluj și Bistrița. Hârtie kraft, textile, carton, eco-friendly. AMAprint Dej.',
      },
    ],
    gradient: 'from-[#30d2be] to-[#00d082]',
    metaTitle: 'Produse Promoționale Personalizate Dej | AMAprint - Promoționale Dej și Împrejurimi',
    metaDesc: 'Produse promoționale personalizate în Dej, Gherla, Beclean, Cluj și Bistrița: pixuri, agende, calendare, căni, pungi cu logo. AMAprint Dej.',
  },
  {
    slug: 'cadouri-personalizate',
    icon: Printer,
    title: 'Cadouri Personalizate',
    desc: 'Cadouri unice și personalizate pentru orice ocazie. Transformă ideile tale în realitate.',
    items: [
      {
        slug: 'tricouri',
        name: 'Tricouri',
        desc: 'Tricouri personalizate cu design unic, pentru echipe, evenimente sau cadouri.',
        fullDesc: 'Tricourile personalizate sunt ideale pentru echipe, evenimente, campanii promoționale sau cadouri unice. AMAprint Dej oferă personalizare prin transfer termic, sublimare, serigrafie și broderie. Disponibile în diverse culori, mărimi (XS-5XL) și materiale (bumbac 100%, poliester, mix). Realizăm tricouri pentru echipe sportive, uniforme corporate, evenimente speciale și cadouri personalizate cu fotografii sau mesaje.',
        features: ['Transfer termic DTF', 'Sublimare full print', 'Serigrafie', 'Broderie', 'Mărimi XS-5XL', 'Bumbac/Poliester/Mix'],
        benefits: ['Culori vibrante și durabile', 'Rezistență la spălări repetate', 'Personalizare completă', 'Tiraje de la 1 bucată'],
        metaTitle: 'Tricouri Personalizate Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Tricouri personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Transfer termic, sublimare, serigrafie, broderie. AMAprint Dej.',
      },
      {
        slug: 'veste',
        name: 'Veste',
        desc: 'Veste personalizate pentru echipe și evenimente speciale.',
        fullDesc: 'Vestele personalizate sunt perfecte pentru echipe, evenimente outdoor, uniforme de lucru și campanii promoționale. AMAprint Dej oferă veste personalizate prin broderie, serigrafie sau transfer termic. Disponibile în diverse materiale: softshell, fleece, bumbac și materiale reflectorizante pentru siguranță. Ideale pentru echipe de construcții, voluntari, echipe sportive și personal de serviciu.',
        features: ['Veste softshell', 'Veste fleece', 'Veste reflectorizante', 'Broderie logo', 'Serigrafie', 'Mărimi S-5XL'],
        benefits: ['Aspect profesional pentru echipe', 'Materiale de calitate', 'Personalizare durabilă', 'Diverse modele disponibile'],
        metaTitle: 'Veste Personalizate Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Veste personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Softshell, fleece, broderie, serigrafie. Echipe și evenimente. AMAprint Dej.',
      },
      {
        slug: 'cani-cadou',
        name: 'Căni',
        desc: 'Căni foto personalizate, cadoul perfect pentru orice ocazie.',
        fullDesc: 'Cănile foto personalizate sunt cadouri perfecte pentru orice ocazie: zile de naștere, aniversări, Crăciun, Paște sau pur și simplu pentru a face pe cineva fericit. AMAprint Dej realizează căni personalizate cu fotografii, mesaje, desene sau colaje. Disponibile în diverse modele: căni clasice albe, căni colorate, căni magice care dezvăluie imaginea la căldură și căni cu interior colorat.',
        features: ['Căni foto personalizate', 'Căni magice', 'Căni cu interior colorat', 'Sublimare HD', 'Cutie cadou inclusă', 'De la 1 bucată'],
        benefits: ['Cadou unic și emoționant', 'Calitate foto HD', 'Rezistent la spălare', 'Livrare rapidă'],
        metaTitle: 'Căni Foto Personalizate Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Căni foto personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Căni magice, sublimare HD, cutie cadou. AMAprint Dej.',
      },
      {
        slug: 'tablouri',
        name: 'Tablouri',
        desc: 'Tablouri personalizate cu fotografii sau design grafic.',
        fullDesc: 'Tablourile personalizate transformă fotografiile și amintirile în opere de artă pentru perete. AMAprint Dej realizează tablouri pe canvas (pânză), tablouri pe forex (PVC expandat), tablouri pe plexiglas și tablouri pe lemn. Disponibile în diverse dimensiuni, de la 20x30cm la 100x150cm. Ideale pentru decorarea casei, biroului sau ca cadouri speciale pentru persoanele dragi.',
        features: ['Canvas/Pânză', 'Forex/PVC', 'Plexiglas', 'Lemn natural', 'Dimensiuni 20x30 - 100x150cm', 'Sistem de agățare inclus'],
        benefits: ['Amintiri transformate în artă', 'Materiale premium', 'Culori vibrante și durabile', 'Cadou emoționant și unic'],
        metaTitle: 'Tablouri Personalizate Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Tablouri personalizate pe canvas, forex, plexiglas în Dej, Gherla, Beclean, Cluj și Bistrița. Fotografii HD, diverse dimensiuni. AMAprint Dej.',
      },
      {
        slug: 'poze',
        name: 'Poze',
        desc: 'Printare foto de înaltă calitate pe diverse materiale.',
        fullDesc: 'Printarea foto profesională păstrează amintirile tale în cea mai bună calitate. AMAprint Dej oferă printare foto pe hârtie fotografică lucioasă sau mată, în diverse formate: 10x15, 13x18, 15x21, 20x30, A4, A3 și formate personalizate. Realizăm și albume foto personalizate, foto-cărți, foto-calendare și foto-magneti. Calitate profesională cu echipamente de ultimă generație.',
        features: ['Hârtie foto lucioasă/mată', 'Formate 10x15 - A3', 'Albume foto', 'Foto-cărți', 'Foto-magneti', 'Calitate profesională'],
        benefits: ['Amintiri păstrate impecabil', 'Calitate foto profesională', 'Diverse formate și opțiuni', 'Prețuri accesibile'],
        metaTitle: 'Printare Foto Profesională Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Printare foto profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Hârtie foto premium, albume, foto-cărți. AMAprint Dej.',
      },
      {
        slug: 'pixuri-cadou',
        name: 'Pixuri',
        desc: 'Pixuri gravate sau imprimate, un cadou elegant și util.',
        fullDesc: 'Pixurile gravate sunt cadouri elegante și utile, perfecte pentru ocazii speciale. AMAprint Dej oferă pixuri premium din metal, cu gravură laser personalizată. Disponibile în diverse culori și modele, cu cutii cadou elegante. Ideale pentru cadouri de afaceri, cadouri pentru profesori, cadouri de absolvire sau cadouri personalizate pentru persoanele dragi. Gravura laser asigură durabilitate permanentă.',
        features: ['Pixuri metalice premium', 'Gravură laser personalizată', 'Cutie cadou elegantă', 'Diverse culori', 'Modele slim și clasice', 'De la 1 bucată'],
        benefits: ['Cadou elegant și util', 'Gravură permanentă', 'Aspect premium', 'Personalizare cu nume/mesaj'],
        metaTitle: 'Pixuri Gravate Cadou Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
        metaDesc: 'Pixuri gravate laser cadou în Dej, Gherla, Beclean, Cluj și Bistrița. Pixuri metalice premium, cutie cadou, personalizare. AMAprint Dej.',
      },
    ],
    gradient: 'from-[#6a11cb] to-[#2575fc]',
    metaTitle: 'Cadouri Personalizate Dej | AMAprint - Cadouri Personalizate Dej și Împrejurimi',
    metaDesc: 'Cadouri personalizate în Dej, Gherla, Beclean, Cluj și Bistrița: tricouri, căni, tablouri, poze personalizate. Cadouri unice. AMAprint Dej.',
  },
  {
    slug: 'reclame',
    icon: Printer,
    title: 'Reclame',
    desc: 'Soluții complete de publicitate vizuală pentru afacerea ta. De la bannere la inscripționare auto.',
    items: [
      {
        slug: 'totemuri',
        name: 'Totemuri',
        desc: 'Totemuri publicitare de impact pentru vizibilitate maximă.',
        fullDesc: 'Totemurile publicitare sunt structuri verticale de mare impact vizual, ideale pentru atragerea atenției clienților. AMAprint Dej proiectează și produce totemuri publicitare din diverse materiale: aluminiu, PVC, plexiglas și materiale compozite. Disponibile cu iluminare LED integrată pentru vizibilitate nocturnă. Ideale pentru benzinării, centre comerciale, showroom-uri și intrări în parcuri industriale.',
        features: ['Aluminiu și PVC', 'Iluminare LED', 'Rezistente la intemperii', 'Design personalizat', 'Montaj inclus', 'Diverse dimensiuni'],
        benefits: ['Vizibilitate maximă', 'Impact vizual puternic', 'Durabilitate în exterior', 'Atragerea clienților'],
        metaTitle: 'Totemuri Publicitare Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Totemuri publicitare în Dej, Gherla, Beclean, Cluj și Bistrița. Iluminare LED, design personalizat, montaj inclus. AMAprint Dej.',
      },
      {
        slug: 'casete-luminoase',
        name: 'Casete Luminoase',
        desc: 'Casete luminoase pentru semnalizare și publicitate nocturnă.',
        fullDesc: 'Casetele luminoase sunt soluții eficiente de semnalizare și publicitate, vizibile atât ziua cât și noaptea. AMAprint Dej realizează casete luminoase cu iluminare LED, casete cu o față sau două fețe, casete rotunde și casete cu forme personalizate. Structura din aluminiu asigură durabilitate, iar fețele din plexiglas sau policarbonat oferă o iluminare uniformă și atractivă.',
        features: ['Iluminare LED eficientă', 'O față sau două fețe', 'Structură aluminiu', 'Fețe plexiglas/policarbonat', 'Forme personalizate', 'Montaj și cablare'],
        benefits: ['Vizibilitate 24/7', 'Consum redus de energie', 'Durabilitate în exterior', 'Aspect profesional'],
        metaTitle: 'Casete Luminoase Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Casete luminoase LED în Dej, Gherla, Beclean, Cluj și Bistrița. Aluminiu, plexiglas, montaj inclus. AMAprint Dej.',
      },
      {
        slug: 'litere-polistiren',
        name: 'Litere Polistiren',
        desc: 'Litere din polistiren pentru decorațiuni și semnalistică.',
        fullDesc: 'Literele din polistiren sunt soluții accesibile și versatile pentru decorațiuni și semnalistică. AMAprint Dej realizează litere și forme din polistiren expandat (EPS), cu diverse finisaje: vopsire, placare cu PVC sau folie autoadezivă. Disponibile în orice dimensiune, de la litere mici decorative la litere de mari dimensiuni pentru evenimente. Ideale pentru nunți, botezuri, evenimente corporate și decorațiuni interioare.',
        features: ['Polistiren expandat EPS', 'Vopsire în orice culoare', 'Placare PVC/folie', 'Orice dimensiune', 'Forme personalizate', 'Livrare rapidă'],
        benefits: ['Cost accesibil', 'Ușoare și ușor de montat', 'Versatilitate în design', 'Ideale pentru evenimente'],
        metaTitle: 'Litere Polistiren Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Litere din polistiren în Dej, Gherla, Beclean, Cluj și Bistrița. Decorațiuni, semnalistică, evenimente. Orice dimensiune. AMAprint Dej.',
      },
      {
        slug: 'panouri-publicitare',
        name: 'Panouri Publicitare',
        desc: 'Panouri publicitare de mari dimensiuni pentru campanii outdoor.',
        fullDesc: 'Panourile publicitare sunt instrumente esențiale pentru campaniile de marketing outdoor. AMAprint Dej realizează panouri publicitare pe diverse materiale: bond, forex, aluminiu compozit (dibond), plexiglas și mesh. Disponibile în orice dimensiune, cu structură metalică de susținere și montaj profesional. Ideale pentru fațade de clădiri, garduri de șantier, panouri direcționale și publicitate stradală.',
        features: ['Bond/Forex/Dibond', 'Plexiglas și mesh', 'Structură metalică', 'Orice dimensiune', 'Montaj profesional', 'Rezistente UV'],
        benefits: ['Vizibilitate la distanță mare', 'Durabilitate în exterior', 'Impact vizual puternic', 'Cost eficient per impresie'],
        metaTitle: 'Panouri Publicitare Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Panouri publicitare în Dej, Gherla, Beclean, Cluj și Bistrița. Bond, forex, dibond, montaj profesional. AMAprint Dej.',
      },
      {
        slug: 'banere-mesh',
        name: 'Banere & Mesh',
        desc: 'Bannere și mesh-uri pentru evenimente, construcții și publicitate.',
        fullDesc: 'Bannerele și mesh-urile sunt materiale publicitare versatile și accesibile. AMAprint Dej realizează bannere din PVC (frontlit și backlit), mesh-uri perforate pentru fațade și bannere textile pentru interior. Disponibile în orice dimensiune, cu finisare profesională: ochi metalici, buzunare pentru bară și cusături de întărire. Ideale pentru evenimente, construcții, târguri, stadion și publicitate outdoor.',
        features: ['PVC frontlit/backlit', 'Mesh perforat', 'Banner textil', 'Ochi metalici', 'Orice dimensiune', 'Finisare profesională'],
        benefits: ['Cost accesibil', 'Montaj rapid și ușor', 'Rezistență la intemperii', 'Impact vizual mare'],
        metaTitle: 'Bannere și Mesh Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Bannere PVC și mesh în Dej, Gherla, Beclean, Cluj și Bistrița. Orice dimensiune, ochi metalici, finisare profesională. AMAprint Dej.',
      },
      {
        slug: 'inscriptionare-auto',
        name: 'Inscripționare Auto',
        desc: 'Inscripționare auto profesională pentru flotă și vehicule comerciale.',
        fullDesc: 'Inscripționarea auto transformă vehiculele în panouri publicitare mobile. AMAprint Dej realizează inscripționare auto cu folii autoadezive de calitate premium, rezistente la UV, spălare și intemperii. Oferim inscripționare parțială sau totală (car wrapping), design grafic personalizat și montaj profesional. Ideale pentru flote comerciale, mașini de firmă, autoutilitare și vehicule de livrare.',
        features: ['Folii premium 3M/Oracal', 'Car wrapping total', 'Inscripționare parțială', 'Design grafic inclus', 'Montaj profesional', 'Rezistență 5-7 ani'],
        benefits: ['Publicitate mobilă 24/7', 'Cost eficient pe termen lung', 'Protecție a vopselei originale', 'Impact vizual în trafic'],
        metaTitle: 'Inscripționare Auto Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Inscripționare auto profesională în Dej, Gherla, Beclean, Cluj și Bistrița. Car wrapping, folii premium, montaj profesional. AMAprint Dej.',
      },
      {
        slug: 'decor-vitrine',
        name: 'Decor Vitrine',
        desc: 'Decor vitrine cu autocolant pentru magazine și showroom-uri.',
        fullDesc: 'Decorul de vitrine transformă ferestrele magazinelor în instrumente de marketing eficiente. AMAprint Dej realizează decor de vitrine cu folii autoadezive, folii sablate (frosted), folii one-way vision și folii transparente printate. Ideale pentru magazine, showroom-uri, birouri, clinici și restaurante. Oferim design grafic personalizat și montaj profesional.',
        features: ['Folii autoadezive', 'Folii sablate/frosted', 'One-way vision', 'Folii transparente', 'Design personalizat', 'Montaj profesional'],
        benefits: ['Atragerea clienților', 'Intimitate cu stil', 'Branding vizibil', 'Ușor de actualizat'],
        metaTitle: 'Decor Vitrine Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Decor vitrine cu autocolant în Dej, Gherla, Beclean, Cluj și Bistrița. Folii sablate, one-way vision, montaj profesional. AMAprint Dej.',
      },
      {
        slug: 'steaguri',
        name: 'Steaguri',
        desc: 'Steaguri personalizate pentru evenimente și promovare.',
        fullDesc: 'Steagurile personalizate sunt instrumente de promovare vizibilă și dinamică. AMAprint Dej realizează steaguri din poliester de calitate, cu imprimare prin sublimare pentru culori vibrante pe ambele fețe. Disponibile în diverse forme: steaguri dreptunghiulare, steaguri tip lacrimă (teardrop), steaguri tip pană (feather) și steaguri de masă. Cu baze și catarge incluse.',
        features: ['Poliester premium', 'Sublimare ambele fețe', 'Steaguri lacrimă/pană', 'Steaguri de masă', 'Baze și catarge', 'Diverse dimensiuni'],
        benefits: ['Vizibilitate dinamică', 'Culori vibrante', 'Ușor de transportat', 'Reutilizabile'],
        metaTitle: 'Steaguri Personalizate Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Steaguri personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Steaguri lacrimă, pană, sublimare, baze incluse. AMAprint Dej.',
      },
      {
        slug: 'roll-up',
        name: 'Roll-Up',
        desc: 'Roll-up-uri portabile pentru târguri, expoziții și prezentări.',
        fullDesc: 'Roll-up-urile sunt sisteme de prezentare portabile, ideale pentru târguri, expoziții, conferințe și prezentări de companie. AMAprint Dej oferă roll-up-uri standard (85x200cm), roll-up-uri wide (100x200cm, 120x200cm) și mini roll-up-uri de masă. Structura din aluminiu este ușoară și durabilă, cu geantă de transport inclusă. Printul pe material banner de calitate asigură culori vibrante și rezistență.',
        features: ['Dimensiuni 85x200, 100x200cm', 'Mini roll-up de masă', 'Structură aluminiu', 'Geantă transport inclusă', 'Material banner premium', 'Montaj în 30 secunde'],
        benefits: ['Portabilitate maximă', 'Impact vizual profesional', 'Reutilizabil', 'Montaj instant'],
        metaTitle: 'Roll-Up Personalizate Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Roll-up-uri personalizate în Dej, Gherla, Beclean, Cluj și Bistrița. Structură aluminiu, geantă transport, montaj rapid. AMAprint Dej.',
      },
      {
        slug: 'litere-volumetrice-3d',
        name: 'Litere Volumetrice 3D',
        desc: 'Litere volumetrice 3D pentru semnalistică premium.',
        fullDesc: 'Literele volumetrice 3D oferă un aspect premium și profesional semnalisticii companiei. AMAprint Dej realizează litere volumetrice din diverse materiale: aluminiu, inox, plexiglas, PVC și lemn. Disponibile cu iluminare LED frontală, laterală sau din spate (halo effect). Ideale pentru fațade de clădiri, recepții, showroom-uri și birouri. Montaj profesional inclus.',
        features: ['Aluminiu/Inox/Plexiglas', 'PVC și lemn', 'Iluminare LED frontală', 'Efect halo (backlit)', 'Orice dimensiune', 'Montaj profesional'],
        benefits: ['Aspect premium', 'Vizibilitate zi și noapte', 'Durabilitate excepțională', 'Impresie profesională'],
        metaTitle: 'Litere Volumetrice 3D Dej | AMAprint - Reclame Dej și Împrejurimi',
        metaDesc: 'Litere volumetrice 3D în Dej, Gherla, Beclean, Cluj și Bistrița. Aluminiu, inox, plexiglas, iluminare LED. AMAprint Dej.',
      },
    ],
    gradient: 'from-[#020381] to-[#30d2be]',
    metaTitle: 'Reclame și Publicitate Vizuală Dej | AMAprint - Reclame Dej și Împrejurimi',
    metaDesc: 'Reclame și publicitate vizuală în Dej, Gherla, Beclean, Cluj și Bistrița: bannere, casete luminoase, inscripționare auto, roll-up, panouri. AMAprint Dej.',
  },
];

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  readTime: string;
  content: string;
}

export const blogPosts: BlogPost[] = [
  {
    slug: 'cum-sa-alegi-tipul-de-print-potrivit',
    title: 'Cum să Alegi Tipul de Print Potrivit pentru Afacerea Ta',
    excerpt: 'Ghid complet despre diferitele tipuri de print disponibile și cum să alegi soluția optimă pentru nevoile afacerii tale.',
    date: '2025-03-05',
    category: 'Ghiduri',
    readTime: '5 min',
    content: `Alegerea tipului de print potrivit poate face diferența între o campanie de marketing reușită și una mediocră. În acest articol, vom explora principalele metode de tipărire disponibile și vom oferi sfaturi practice pentru a alege soluția optimă.

**Print Digital** - Ideal pentru tiraje mici și medii, cu timp de execuție rapid. Perfect pentru cărți de vizită, flyere și materiale promoționale urgente.

**Print Offset** - Recomandat pentru tiraje mari, oferind o calitate superioară a culorilor și un cost per unitate mai mic la volume mari.

**Serigrafie** - Excelentă pentru imprimarea pe materiale non-standard: textile, ceramică, plastic. Culorile sunt vibrante și durabile.

**Sublimare** - Ideală pentru personalizarea obiectelor precum căni, tricouri și alte produse promoționale cu imagini foto-realiste.

La AMAprint, vă putem consilia gratuit pentru a alege metoda de print optimă pentru proiectul dumneavoastră. Contactați-ne pentru o ofertă personalizată!`,
  },
  {
    slug: 'avantajele-gravurii-laser',
    title: 'Avantajele Gravurii Laser: De Ce Să Alegi Această Tehnologie',
    excerpt: 'Descoperă beneficiile gravurii laser pentru personalizarea cadourilor, trofeelor și obiectelor decorative.',
    date: '2025-02-20',
    category: 'Tehnologie',
    readTime: '4 min',
    content: `Gravura laser a revoluționat modul în care personalizăm obiectele. Această tehnologie oferă o precizie excepțională și rezultate durabile pe o varietate de materiale.

**Precizie Maximă** - Gravura laser poate reproduce detalii incredibil de fine, de la texte mici la imagini complexe, cu o acuratețe imposibil de atins prin metode tradiționale.

**Versatilitate** - Putem grava pe lemn, sticlă, metal, plastic, piele și multe alte materiale. Fiecare material oferă un efect vizual unic.

**Durabilitate** - Spre deosebire de imprimare sau vopsire, gravura laser este permanentă. Nu se șterge, nu se decolorează și rezistă la uzură.

**Aplicații Populare:**
- Trofee și plăci comemorative
- Cadouri personalizate (brichete, pixuri, căni)
- Decorațiuni interioare
- Semnalistică profesională
- Bijuterii personalizate

La AMAprint Dej, dispunem de echipamente laser de ultimă generație. Vizitați-ne pentru a vedea mostre și a discuta despre proiectul dumneavoastră!`,
  },
  {
    slug: 'ghid-cadouri-personalizate-corporate',
    title: 'Ghid Complet: Cadouri Personalizate Corporate pentru Evenimente',
    excerpt: 'Idei creative și sfaturi practice pentru alegerea cadourilor personalizate perfecte pentru evenimentele corporate.',
    date: '2025-02-10',
    category: 'Idei',
    readTime: '6 min',
    content: `Cadourile personalizate corporate sunt o modalitate excelentă de a consolida relațiile de afaceri și de a crește vizibilitatea brandului. Iată un ghid complet pentru alegerea cadourilor potrivite.

**Pentru Conferințe și Seminarii:**
- Agende personalizate cu logo
- Pixuri premium gravate
- Pungi eco-friendly cu branding
- Badge-uri și lanyard-uri personalizate

**Pentru Sărbători și Aniversări:**
- Căni personalizate cu mesaje
- Tricouri cu design special
- Calendare de birou personalizate
- Cutii cadou cu produse mixte

**Pentru Clienți VIP:**
- Obiecte gravate laser (brichete, pixuri premium)
- Tablouri personalizate
- Seturi cadou premium
- Articole textile brodate

**Sfaturi Practice:**
1. Alegeți cadouri utile, nu doar decorative
2. Asigurați-vă că logo-ul este vizibil dar elegant
3. Investiți în calitate - cadoul reprezintă brandul
4. Planificați din timp pentru tiraje mari

AMAprint vă poate ajuta cu toate aceste produse, de la design până la livrare. Solicită o ofertă personalizată!`,
  },
  {
    slug: 'importanta-cartilor-de-vizita',
    title: 'De Ce Cărțile de Vizită Rămân Esențiale în Era Digitală',
    excerpt: 'Află de ce cărțile de vizită fizice sunt încă un instrument puternic de networking și branding în 2025.',
    date: '2025-01-28',
    category: 'Marketing',
    readTime: '4 min',
    content: `Într-o lume tot mai digitalizată, cărțile de vizită fizice rămân un instrument de networking surprinzător de eficient. Iată de ce ar trebui să investiți în cărți de vizită de calitate.

**Impact Tangibil** - O carte de vizită fizică creează o conexiune mai puternică decât un schimb digital de contacte. Textura hârtiei, designul și calitatea imprimării comunică profesionalism.

**Memorabilitate** - Studiile arată că oamenii rețin mai bine informațiile primite pe suport fizic. O carte de vizită bine realizată va fi păstrată și consultată ulterior.

**Diferențiere** - Într-o mare de contacte digitale, o carte de vizită elegantă te face să ieși în evidență.

**Tendințe 2025:**
- Hârtie premium cu texturi speciale
- Finisaje de lux (folio auriu, lăcuire UV selectivă)
- Design minimalist și elegant
- Coduri QR integrate pentru link digital
- Forme non-standard (rotunde, die-cut)

La AMAprint, oferim cărți de vizită pe hârtie premium, cu diverse finisaje și opțiuni de personalizare. De la design la livrare, suntem alături de tine!`,
  },
];