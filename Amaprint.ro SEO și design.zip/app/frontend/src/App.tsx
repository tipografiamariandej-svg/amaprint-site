import { useEffect } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Index from './pages/Index';
import Servicii from './pages/Servicii';
import ServiceDetail from './pages/ServiceDetail';
import Produse from './pages/Produse';
import ProductDetail from './pages/ProductDetail';
import ProductItemDetail from './pages/ProductItemDetail';
import { BlogList, BlogPost } from './pages/Blog';
import Contact from './pages/Contact';
import GDPR from './pages/GDPR';
import Termeni from './pages/Termeni';
import NotFound from './pages/NotFound';
import AuthCallback from './pages/AuthCallback';
import AuthError from './pages/AuthError';

const queryClient = new QueryClient();

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/servicii" element={<Servicii />} />
          <Route path="/servicii/:slug" element={<ServiceDetail />} />
          <Route path="/produse" element={<Produse />} />
          <Route path="/produse/:slug" element={<ProductDetail />} />
          <Route path="/produse/:categorySlug/:itemSlug" element={<ProductItemDetail />} />
          <Route path="/blog" element={<BlogList />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/gdpr" element={<GDPR />} />
          <Route path="/termeni" element={<Termeni />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/auth/error" element={<AuthError />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;