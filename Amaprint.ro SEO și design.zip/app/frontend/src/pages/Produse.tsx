import Layout from '@/components/Layout';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Phone, BookOpen, Gift, Megaphone, FileText, MapPin } from 'lucide-react';
import { productCategories, SERVICE_AREAS, PRODUCTS_IMG } from '@/data/services';

const iconMap: Record<string, React.ElementType> = {
  tipografie: FileText,
  promotionale: Gift,
  'cadouri-personalizate': BookOpen,
  reclame: Megaphone,
};

export default function Produse() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={PRODUCTS_IMG} alt="Produse promoționale și tipografice AMAprint Dej" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#020381]/85" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Produsele Noastre</h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto">
            Oferim o gamă variată de produse tipografice, promoționale, cadouri personalizate și soluții de publicitate vizuală.
          </p>
          <div className="flex items-center justify-center gap-2 mt-4 text-white/50 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Deservim zonele: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 space-y-16">
          {productCategories.map((cat) => {
            const Icon = iconMap[cat.slug] || FileText;
            return (
              <article key={cat.title} id={cat.slug}>
                <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center shrink-0`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl md:text-3xl font-bold text-[#020381]">{cat.title}</h2>
                      <p className="text-gray-500 text-sm">{cat.desc}</p>
                    </div>
                  </div>
                  <Link to={`/produse/${cat.slug}`}>
                    <Button variant="outline" className="border-[#020381] text-[#020381] font-semibold hover:bg-[#020381] hover:text-white text-sm">
                      Vezi Toate
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {cat.items.slice(0, 6).map((item) => (
                    <Card key={item.name} className="border border-gray-100 hover:border-[#30d2be]/30 hover:shadow-md transition-all duration-300 group">
                      <CardContent className="p-5">
                        <h3 className="font-semibold text-[#020381] mb-1.5 group-hover:text-[#30d2be] transition-colors">{item.name}</h3>
                        <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {cat.items.length > 6 && (
                  <div className="text-center mt-4">
                    <Link to={`/produse/${cat.slug}`} className="text-[#30d2be] font-semibold text-sm hover:underline">
                      + {cat.items.length - 6} produse în plus →
                    </Link>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#30d2be] to-[#00d082]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Interesat de Produsele Noastre?</h2>
          <p className="text-white/90 mb-8">Solicită o ofertă personalizată și beneficiezi de prețuri competitive!</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#020381] font-bold hover:bg-gray-100 shadow-lg">
                Solicită Ofertă
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold hover:!bg-white/10">
                WhatsApp
              </Button>
            </a>
            <a href="tel:0799134444">
              <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold hover:!bg-white/10">
                <Phone className="w-5 h-5 mr-2" />
                0799 134 444
              </Button>
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}