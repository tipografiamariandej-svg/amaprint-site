import { useParams, Link, Navigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Phone, ArrowLeft, CheckCircle2, MapPin } from 'lucide-react';
import { services, SERVICE_AREAS } from '@/data/services';
import { useEffect } from 'react';

export default function ServiceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const service = services.find((s) => s.slug === slug);

  useEffect(() => {
    if (service) {
      document.title = service.metaTitle;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', service.metaDesc);
    }
  }, [service]);

  if (!service) {
    return <Navigate to="/servicii" replace />;
  }

  const Icon = service.icon;
  const otherServices = services.filter((s) => s.slug !== slug).slice(0, 3);

  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden">
        {service.image && (
          <>
            <div className="absolute inset-0">
              <img src={service.image} alt={`${service.title} - AMAprint Dej`} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-[#020381]/85" />
            </div>
          </>
        )}
        {!service.image && <div className="absolute inset-0 bg-gradient-to-br from-[#020381] to-[#020381]/90" />}
        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
          <Link to="/servicii" className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Înapoi la Servicii
          </Link>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#30d2be] to-[#00d082] flex items-center justify-center">
              <Icon className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white">{service.title}</h1>
          </div>
          <p className="text-white/70 text-lg max-w-2xl">{service.shortDesc}</p>
          <div className="flex items-center gap-2 mt-4 text-white/60 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Disponibil în: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main content */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold text-[#020381] mb-4">Despre Serviciul de {service.title}</h2>
              <p className="text-gray-600 leading-relaxed text-lg mb-8">{service.fullDesc}</p>

              <h3 className="text-xl font-bold text-[#020381] mb-4">Caracteristici</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                {service.features.map((f) => (
                  <div key={f} className="flex items-center gap-3 bg-[#f5f7fa] rounded-xl p-4">
                    <CheckCircle2 className="w-5 h-5 text-[#30d2be] shrink-0" />
                    <span className="text-gray-700 font-medium">{f}</span>
                  </div>
                ))}
              </div>

              <h3 className="text-xl font-bold text-[#020381] mb-4">Beneficii</h3>
              <div className="space-y-3 mb-8">
                {service.benefits.map((b) => (
                  <div key={b} className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-[#30d2be] mt-2 shrink-0" />
                    <p className="text-gray-600">{b}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="border-0 shadow-lg bg-gradient-to-br from-[#020381] to-[#020381]/90 text-white">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-3">Solicită o Ofertă</h3>
                  <p className="text-white/70 text-sm mb-5">
                    Contactează-ne pentru o ofertă personalizată pentru serviciul de {service.title.toLowerCase()}.
                  </p>
                  <div className="space-y-3">
                    <Link to="/contact" className="block">
                      <Button className="w-full bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90">
                        Cere Ofertă
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                    <a href="tel:0799134444" className="block">
                      <Button variant="outline" className="w-full !bg-transparent border-white/30 text-white hover:!bg-white/10">
                        <Phone className="w-4 h-4 mr-2" />
                        0799 134 444
                      </Button>
                    </a>
                    <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer" className="block">
                      <Button variant="outline" className="w-full !bg-transparent border-[#25D366]/50 text-[#25D366] hover:!bg-[#25D366]/10">
                        WhatsApp
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <h3 className="font-bold text-[#020381] mb-3">Zona de Acoperire</h3>
                  <div className="flex flex-wrap gap-2">
                    {SERVICE_AREAS.map((area) => (
                      <span key={area} className="bg-[#30d2be]/10 text-[#020381] text-sm px-3 py-1.5 rounded-full font-medium">
                        {area}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Other Services */}
      <section className="py-16 bg-[#f5f7fa]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-[#020381] mb-8">Alte Servicii</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {otherServices.map((s) => {
              const SIcon = s.icon;
              return (
                <Link key={s.slug} to={`/servicii/${s.slug}`}>
                  <Card className="border-0 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#30d2be]/20 to-[#00d082]/20 flex items-center justify-center mb-4">
                        <SIcon className="w-6 h-6 text-[#30d2be]" />
                      </div>
                      <h3 className="font-bold text-[#020381] text-lg mb-2">{s.title}</h3>
                      <p className="text-gray-500 text-sm">{s.shortDesc}</p>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>
    </Layout>
  );
}