import Layout from '@/components/Layout';

export default function GDPR() {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Politica de Confidențialitate</h1>
          <p className="text-white/70">GDPR - Protecția Datelor cu Caracter Personal</p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 prose prose-lg max-w-none">
          <article className="space-y-8 text-gray-600 leading-relaxed">
            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">1. Informații Generale</h2>
              <p>
                AMADESIGN SRL (denumită în continuare "AMAprint", "noi" sau "compania"), cu sediul în Str. Florilor 18, Dej, Jud. Cluj, România, se angajează să protejeze confidențialitatea datelor dumneavoastră cu caracter personal, în conformitate cu Regulamentul (UE) 2016/679 (GDPR).
              </p>
              <p>
                Această politică de confidențialitate descrie modul în care colectăm, utilizăm, stocăm și protejăm datele dumneavoastră personale atunci când vizitați site-ul nostru web amaprint.ro sau utilizați serviciile noastre.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">2. Datele Colectate</h2>
              <p>Putem colecta următoarele categorii de date personale:</p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Nume și prenume</li>
                <li>Adresă de email</li>
                <li>Număr de telefon</li>
                <li>Adresă poștală</li>
                <li>Date de navigare (cookies, adresă IP)</li>
                <li>Informații despre comenzi și preferințe</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">3. Scopul Prelucrării</h2>
              <p>Datele dumneavoastră personale sunt prelucrate în următoarele scopuri:</p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Procesarea și livrarea comenzilor</li>
                <li>Comunicarea cu clienții (oferte, informații, suport)</li>
                <li>Îmbunătățirea serviciilor noastre</li>
                <li>Respectarea obligațiilor legale</li>
                <li>Marketing direct (doar cu consimțământul dumneavoastră)</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">4. Temeiul Legal</h2>
              <p>Prelucrarea datelor se bazează pe:</p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Consimțământul dumneavoastră explicit</li>
                <li>Executarea unui contract</li>
                <li>Obligații legale</li>
                <li>Interesul nostru legitim</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">5. Drepturile Dumneavoastră</h2>
              <p>Conform GDPR, aveți următoarele drepturi:</p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li><strong>Dreptul de acces</strong> - puteți solicita informații despre datele prelucrate</li>
                <li><strong>Dreptul la rectificare</strong> - puteți cere corectarea datelor inexacte</li>
                <li><strong>Dreptul la ștergere</strong> - puteți solicita ștergerea datelor</li>
                <li><strong>Dreptul la restricționare</strong> - puteți limita prelucrarea datelor</li>
                <li><strong>Dreptul la portabilitate</strong> - puteți primi datele într-un format structurat</li>
                <li><strong>Dreptul la opoziție</strong> - puteți vă opune prelucrării datelor</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">6. Securitatea Datelor</h2>
              <p>
                Implementăm măsuri tehnice și organizatorice adecvate pentru a proteja datele dumneavoastră împotriva accesului neautorizat, pierderii sau distrugerii. Datele sunt stocate pe servere securizate și accesul este restricționat doar personalului autorizat.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">7. Cookies</h2>
              <p>
                Site-ul nostru utilizează cookies pentru a îmbunătăți experiența de navigare. Puteți gestiona preferințele de cookies prin setările browserului dumneavoastră. Pentru mai multe informații, consultați politica noastră de cookies.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">8. Contact</h2>
              <p>
                Pentru orice întrebări sau solicitări legate de protecția datelor personale, ne puteți contacta la:
              </p>
              <ul className="list-none space-y-1 mt-2">
                <li><strong>Email:</strong> contact@amaprint.ro</li>
                <li><strong>Telefon:</strong> 0799 134 444</li>
                <li><strong>Adresă:</strong> <a href="https://maps.google.com/?q=amamedia+dej" target="_blank" rel="noopener noreferrer" className="text-[#30d2be] hover:underline">Str. Florilor 18, Dej, Jud. Cluj</a></li>
              </ul>
              <p className="mt-3">
                De asemenea, aveți dreptul de a depune o plângere la Autoritatea Națională de Supraveghere a Prelucrării Datelor cu Caracter Personal (ANSPDCP).
              </p>
            </div>

            <div className="border-t border-gray-200 pt-6 text-sm text-gray-400">
              <p>Ultima actualizare: Martie 2025</p>
              <p>AMADESIGN SRL - AMAprint</p>
            </div>
          </article>
        </div>
      </section>
    </Layout>
  );
}