import { useParams, Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { productCategories, SERVICE_AREAS } from '@/data/services';
import { ChevronRight, CheckCircle2, Star, Phone, MessageCircle, ArrowLeft, MapPin } from 'lucide-react';

export default function ProductItemDetail() {
  const { categorySlug, itemSlug } = useParams<{ categorySlug: string; itemSlug: string }>();

  const category = productCategories.find((c) => c.slug === categorySlug);
  const item = category?.items.find((i) => i.slug === itemSlug);

  if (!category || !item) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-[#020381] mb-4">Produs negăsit</h1>
            <p className="text-gray-500 mb-6">Produsul căutat nu a fost găsit.</p>
            <Link to="/produse">
              <Button className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white">
                Înapoi la Produse
              </Button>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  // Find other items in same category for "related products"
  const relatedItems = category.items.filter((i) => i.slug !== itemSlug).slice(0, 3);

  return (
    <Layout>
      {/* SEO - set document title */}
      <title>{item.metaTitle}</title>
      <meta name="description" content={item.metaDesc} />

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
            <Link to="/" className="hover:text-[#30d2be] transition-colors">Acasă</Link>
            <ChevronRight className="w-3 h-3" />
            <Link to="/produse" className="hover:text-[#30d2be] transition-colors">Produse</Link>
            <ChevronRight className="w-3 h-3" />
            <Link to={`/produse/${category.slug}`} className="hover:text-[#30d2be] transition-colors">{category.title}</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-[#020381] font-medium">{item.name}</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <section className={`bg-gradient-to-br ${category.gradient} py-16`}>
        <div className="max-w-7xl mx-auto px-4">
          <Link
            to={`/produse/${category.slug}`}
            className="inline-flex items-center gap-2 text-white/70 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Înapoi la {category.title}
          </Link>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            {item.name} Personalizate Dej
          </h1>
          <p className="text-white/80 text-lg max-w-3xl">{item.desc}</p>
          <div className="flex items-center gap-2 mt-4 text-white/60 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Disponibil în: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left: Description & Features */}
            <div className="lg:col-span-2 space-y-10">
              {/* Full Description */}
              <div>
                <h2 className="text-2xl font-bold text-[#020381] mb-4">
                  Despre {item.name} - AMAprint Dej
                </h2>
                <p className="text-gray-600 leading-relaxed text-lg">{item.fullDesc}</p>
              </div>

              {/* Features */}
              <div>
                <h2 className="text-2xl font-bold text-[#020381] mb-6">
                  Caracteristici {item.name}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {item.features.map((feature) => (
                    <div key={feature} className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl">
                      <CheckCircle2 className="w-5 h-5 text-[#30d2be] mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Benefits */}
              <div>
                <h2 className="text-2xl font-bold text-[#020381] mb-6">
                  De Ce Să Alegi AMAprint Dej pentru {item.name}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {item.benefits.map((benefit) => (
                    <div key={benefit} className="flex items-start gap-3 p-4 border border-[#30d2be]/20 rounded-xl bg-[#30d2be]/5">
                      <Star className="w-5 h-5 text-[#30d2be] mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Service Areas */}
              <div className="bg-[#f5f7fa] rounded-2xl p-6">
                <h3 className="text-lg font-bold text-[#020381] mb-3 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#30d2be]" />
                  Zone Deservite pentru {item.name}
                </h3>
                <p className="text-gray-600 mb-4">
                  Oferim {item.name.toLowerCase()} personalizate în <strong>Dej</strong> și împrejurimi.
                  Livrăm în toate localitățile din județele Cluj și Bistrița-Năsăud.
                </p>
                <div className="flex flex-wrap gap-2">
                  {SERVICE_AREAS.map((area) => (
                    <span key={area} className="bg-white text-[#020381] font-semibold text-sm px-3 py-1.5 rounded-full shadow-sm">
                      📍 {item.name} {area}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: CTA Sidebar */}
            <div className="space-y-6">
              {/* Contact CTA */}
              <Card className="border-0 shadow-lg sticky top-24">
                <CardContent className="p-6 space-y-5">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-[#020381] mb-2">Solicită Ofertă</h3>
                    <p className="text-gray-500 text-sm">
                      Contactează-ne pentru o ofertă personalizată pentru {item.name.toLowerCase()}.
                    </p>
                  </div>

                  <a href="tel:0799134444" className="block">
                    <Button className="w-full bg-gradient-to-r from-[#020381] to-[#2575fc] text-white font-semibold h-12">
                      <Phone className="w-4 h-4 mr-2" />
                      Sună: 0799 134 444
                    </Button>
                  </a>

                  <a
                    href="https://wa.me/40799134444"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <Button className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-semibold h-12">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      WhatsApp: 0799 13 44 44
                    </Button>
                  </a>

                  <Link to="/contact" className="block">
                    <Button variant="outline" className="w-full border-[#30d2be] text-[#020381] font-semibold h-12 hover:bg-[#30d2be]/10">
                      Trimite Mesaj
                    </Button>
                  </Link>

                  <a href="mailto:contact@amaprint.ro" className="block text-center text-sm text-gray-500 hover:text-[#30d2be] transition-colors">
                    contact@amaprint.ro
                  </a>

                  <div className="pt-4 border-t text-center">
                    <p className="text-xs text-gray-400">
                      📍 <a href="https://maps.google.com/?q=amamedia+dej" target="_blank" rel="noopener noreferrer" className="hover:text-[#30d2be] transition-colors">Str. Florilor 18, Dej, Jud. Cluj</a>
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Luni - Vineri: 8:00 - 17:00
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Related Products */}
              {relatedItems.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-[#020381] mb-4">Alte Produse din {category.title}</h3>
                  <div className="space-y-3">
                    {relatedItems.map((related) => (
                      <Link
                        key={related.slug}
                        to={`/produse/${category.slug}/${related.slug}`}
                        className="block p-4 bg-gray-50 rounded-xl hover:bg-[#30d2be]/10 transition-colors group"
                      >
                        <h4 className="font-semibold text-[#020381] group-hover:text-[#30d2be] transition-colors">
                          {related.name}
                        </h4>
                        <p className="text-gray-500 text-sm mt-1 line-clamp-2">{related.desc}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className={`bg-gradient-to-r ${category.gradient} py-16`}>
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ai Nevoie de {item.name} Personalizate?
          </h2>
          <p className="text-white/80 mb-8 text-lg">
            Contactează-ne acum pentru o ofertă personalizată. Deservim zona Dej, Gherla, Beclean, Cluj și Bistrița.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold shadow-lg">
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp
              </Button>
            </a>
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#020381] font-bold hover:bg-gray-100 shadow-lg">
                Solicită Ofertă
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}