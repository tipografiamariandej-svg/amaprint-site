import { useParams, Link, Navigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Phone, ArrowLeft, MapPin } from 'lucide-react';
import { productCategories, SERVICE_AREAS, PRODUCTS_IMG } from '@/data/services';
import { useEffect } from 'react';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const category = productCategories.find((c) => c.slug === slug);

  useEffect(() => {
    if (category) {
      document.title = category.metaTitle;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', category.metaDesc);
    }
  }, [category]);

  if (!category) {
    return <Navigate to="/produse" replace />;
  }

  const otherCategories = productCategories.filter((c) => c.slug !== slug);

  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={PRODUCTS_IMG} alt={`${category.title} - AMAprint Dej`} className="w-full h-full object-cover" />
          <div className={`absolute inset-0 bg-[#020381]/85`} />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
          <Link to="/produse" className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Înapoi la Produse
          </Link>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">{category.title}</h1>
          <p className="text-white/70 text-lg max-w-2xl">{category.desc}</p>
          <div className="flex items-center gap-2 mt-4 text-white/60 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Disponibil în: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-[#020381] mb-8">Produse din Categoria {category.title}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.items.map((item) => (
              <Link key={item.slug} to={`/produse/${category.slug}/${item.slug}`}>
                <Card className="border border-gray-100 hover:border-[#30d2be]/30 hover:shadow-lg transition-all duration-300 group h-full">
                  <CardContent className="p-6">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${category.gradient} flex items-center justify-center mb-4 opacity-80`}>
                      <span className="text-white font-bold text-sm">{item.name.charAt(0)}</span>
                    </div>
                    <h3 className="font-bold text-[#020381] text-lg mb-2 group-hover:text-[#30d2be] transition-colors">{item.name}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed mb-3">{item.desc}</p>
                    <span className="inline-flex items-center gap-1 text-[#30d2be] text-sm font-semibold group-hover:gap-2 transition-all">
                      Vezi Detalii <ArrowRight className="w-4 h-4" />
                    </span>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* CTA inline */}
          <div className="mt-12 bg-gradient-to-r from-[#020381] to-[#020381]/90 rounded-2xl p-8 md:p-12 text-center">
            <h3 className="text-2xl font-bold text-white mb-3">Interesat de {category.title}?</h3>
            <p className="text-white/70 mb-6">Solicită o ofertă personalizată și beneficiezi de prețuri competitive!</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/contact">
                <Button size="lg" className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-bold hover:opacity-90 shadow-lg">
                  Solicită Ofertă
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="outline" className="!bg-transparent border-2 border-[#25D366] text-[#25D366] font-bold hover:!bg-[#25D366]/10">
                  WhatsApp
                </Button>
              </a>
              <a href="tel:0799134444">
                <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold hover:!bg-white/10">
                  <Phone className="w-5 h-5 mr-2" />
                  0799 134 444
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Other Categories */}
      <section className="py-16 bg-[#f5f7fa]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-[#020381] mb-8">Alte Categorii de Produse</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {otherCategories.map((cat) => (
              <Link key={cat.slug} to={`/produse/${cat.slug}`}>
                <Card className="border-0 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full overflow-hidden">
                  <CardContent className="p-0">
                    <div className={`bg-gradient-to-r ${cat.gradient} p-5`}>
                      <h3 className="text-white font-bold text-lg">{cat.title}</h3>
                    </div>
                    <div className="p-5">
                      <p className="text-gray-500 text-sm">{cat.desc}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}