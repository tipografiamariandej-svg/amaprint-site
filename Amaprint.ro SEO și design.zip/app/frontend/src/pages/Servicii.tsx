import Layout from '@/components/Layout';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Phone, MapPin } from 'lucide-react';
import { services, SERVICE_AREAS, LASER_IMG, TEXTILE_IMG } from '@/data/services';

export default function Servicii() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Serviciile Noastre</h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto">
            Amaprint este partenerul dvs. de încredere pentru toate nevoile de tipar și finisare. Contactați-ne pentru a discuta despre proiectul dvs.
          </p>
          <div className="flex items-center justify-center gap-2 mt-4 text-white/50 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Deservim zonele: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 space-y-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isEven = index % 2 === 0;
            const hasImage = service.slug === 'gravura-laser' || service.slug === 'imprimare-textila';
            const image = service.slug === 'gravura-laser' ? LASER_IMG : service.slug === 'imprimare-textila' ? TEXTILE_IMG : undefined;
            return (
              <article key={service.title} id={service.slug}>
                <Link to={`/servicii/${service.slug}`} className="block group">
                  <Card className="border-0 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden">
                    <CardContent className="p-0">
                      <div className={`flex flex-col ${hasImage ? (isEven ? 'lg:flex-row' : 'lg:flex-row-reverse') : ''}`}>
                        {hasImage && image && (
                          <div className="lg:w-2/5 shrink-0">
                            <img
                              src={image}
                              alt={`Serviciu ${service.title} la AMAprint Dej`}
                              className="w-full h-64 lg:h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                          </div>
                        )}
                        <div className={`p-8 ${hasImage ? 'lg:w-3/5' : 'w-full'}`}>
                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#30d2be] to-[#00d082] flex items-center justify-center shrink-0">
                              <Icon className="w-6 h-6 text-white" />
                            </div>
                            <h2 className="text-2xl font-bold text-[#020381] group-hover:text-[#30d2be] transition-colors">{service.title}</h2>
                          </div>
                          <p className="text-gray-600 leading-relaxed mb-5">{service.shortDesc}</p>
                          <div className="flex flex-wrap gap-2 mb-4">
                            {service.features.slice(0, 4).map((f) => (
                              <span key={f} className="inline-flex items-center gap-1.5 bg-[#30d2be]/10 text-[#020381] text-sm px-3 py-1.5 rounded-full font-medium">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#30d2be]" />
                                {f}
                              </span>
                            ))}
                          </div>
                          <span className="inline-flex items-center gap-1 text-[#30d2be] font-semibold text-sm group-hover:gap-2 transition-all">
                            Vezi Detalii
                            <ArrowRight className="w-4 h-4" />
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </article>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#30d2be] to-[#00d082]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ai Nevoie de un Serviciu?</h2>
          <p className="text-white/90 mb-8">Contactează-ne pentru o ofertă personalizată. Răspundem rapid!</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#020381] font-bold hover:bg-gray-100 shadow-lg">
                Cere Ofertă
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold hover:!bg-white/10">
                WhatsApp
              </Button>
            </a>
            <a href="tel:0799134444">
              <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold hover:!bg-white/10">
                <Phone className="w-5 h-5 mr-2" />
                0799 134 444
              </Button>
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}