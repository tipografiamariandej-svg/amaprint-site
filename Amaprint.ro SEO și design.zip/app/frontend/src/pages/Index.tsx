import Layout from '@/components/Layout';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  ArrowRight,
  Phone,
  CheckCircle2,
  Star,
  MapPin,
} from 'lucide-react';
import { services, productCategories, SERVICE_AREAS, HERO_IMG, LASER_IMG, TEXTILE_IMG, PRODUCTS_IMG } from '@/data/services';

const testimonials = [
  { name: 'Maria P.', text: 'Calitate excelentă și livrare rapidă! Cărțile de vizită arată impecabil.', rating: 5 },
  { name: 'Andrei D.', text: 'Am comandat bannere și flyere pentru eveniment. Foarte mulțumit de rezultat!', rating: 5 },
  { name: 'Elena S.', text: 'Gravura laser pe cadouri personalizate a fost perfectă. Recomand cu încredere!', rating: 5 },
];

export default function Index() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Atelier profesional de tipografie AMAprint din Dej cu echipamente moderne de printare"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#020381]/90 via-[#020381]/70 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white/90 text-sm font-medium px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 rounded-full bg-[#30d2be] animate-pulse" />
              Tipografie Profesională în Dej, Gherla, Beclean, Cluj, Bistrița
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
              Tipografie și Print
              <span className="block text-[#30d2be]">Profesional</span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 leading-relaxed mb-8 max-w-xl">
              AMAPRINT este partenerul tău de încredere pentru servicii de tipărire profesională. Realizăm bannere, cărți de vizită, flyere, stickere și materiale promoționale de calitate superioară.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact">
                <Button size="lg" className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold text-base px-8 hover:opacity-90 shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]">
                  Cere Ofertă Gratuită
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-semibold text-base px-8 hover:!bg-white/10 transition-all">
                  <Phone className="w-5 h-5 mr-2" />
                  WhatsApp
                </Button>
              </a>
            </div>
            <div className="flex flex-wrap gap-6 mt-10 text-white/70 text-sm">
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-[#30d2be]" /> Livrare Rapidă</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-[#30d2be]" /> Prețuri Competitive</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-[#30d2be]" /> Calitate Superioară</span>
            </div>
          </div>
        </div>
      </section>

      {/* Service Areas Banner */}
      <section className="bg-[#020381] py-4">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-center gap-3 text-white text-sm">
          <MapPin className="w-4 h-4 text-[#30d2be]" />
          <span>Deservim zonele: <strong>{SERVICE_AREAS.join(' · ')}</strong></span>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-[#f5f7fa]" id="servicii">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Ce oferim</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#020381] mt-2 mb-4">Serviciile Noastre</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Amaprint este partenerul dvs. de încredere pentru toate nevoile de tipar și finisare. Oferim o gamă completă de servicii profesionale.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <Link key={service.slug} to={`/servicii/${service.slug}`}>
                  <Card className="group border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white h-full">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#30d2be]/20 to-[#00d082]/20 flex items-center justify-center mb-4 group-hover:from-[#30d2be] group-hover:to-[#00d082] transition-all duration-300">
                        <Icon className="w-6 h-6 text-[#30d2be] group-hover:text-white transition-colors duration-300" />
                      </div>
                      <h3 className="font-bold text-[#020381] text-lg mb-2 group-hover:text-[#30d2be] transition-colors">{service.title}</h3>
                      <p className="text-gray-500 text-sm leading-relaxed">{service.shortDesc}</p>
                      <span className="inline-flex items-center gap-1 text-[#30d2be] font-semibold text-sm mt-3 group-hover:gap-2 transition-all">
                        Detalii <ArrowRight className="w-4 h-4" />
                      </span>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
          <div className="text-center mt-10">
            <Link to="/servicii">
              <Button variant="outline" className="border-[#020381] text-[#020381] font-semibold hover:bg-[#020381] hover:text-white transition-all">
                Vezi Toate Serviciile
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Images Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Echipamente Moderne</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#020381] mt-2 mb-4">Tehnologie de Ultimă Generație</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Dispunem de echipamente profesionale pentru tiparire și finisare de înaltă calitate.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link to="/servicii/gravura-laser" className="group relative overflow-hidden rounded-2xl shadow-lg">
              <img src={LASER_IMG} alt="Servicii de gravură laser profesională la AMAprint Dej" className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-bold text-lg">Gravură Laser</h3>
              </div>
            </Link>
            <Link to="/servicii/imprimare-textila" className="group relative overflow-hidden rounded-2xl shadow-lg">
              <img src={TEXTILE_IMG} alt="Imprimare textilă profesională pe tricouri și echipamente la AMAprint" className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-bold text-lg">Imprimare Textilă</h3>
              </div>
            </Link>
            <Link to="/produse/promotionale" className="group relative overflow-hidden rounded-2xl shadow-lg">
              <img src={PRODUCTS_IMG} alt="Produse promoționale personalizate - cărți de vizită, pixuri, căni la AMAprint" className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <h3 className="text-white font-bold text-lg">Produse Promoționale</h3>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 bg-[#f5f7fa]" id="produse">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Portofoliu</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#020381] mt-2 mb-4">Categorii de Produse</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              De la materiale tipografice la produse promoționale și reclame, acoperim toate nevoile afacerii tale.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {productCategories.map((cat) => (
              <Link key={cat.slug} to={`/produse/${cat.slug}`}>
                <Card className="border-0 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden group h-full">
                  <CardContent className="p-0">
                    <div className={`bg-gradient-to-r ${cat.gradient} p-6`}>
                      <h3 className="text-white font-bold text-xl">{cat.title}</h3>
                    </div>
                    <div className="p-6">
                      <div className="flex flex-wrap gap-2">
                        {cat.items.slice(0, 6).map((item) => (
                          <span key={item.name} className="inline-block bg-gray-100 text-gray-700 text-sm px-3 py-1.5 rounded-full font-medium">
                            {item.name}
                          </span>
                        ))}
                        {cat.items.length > 6 && (
                          <span className="inline-block bg-[#30d2be]/10 text-[#30d2be] text-sm px-3 py-1.5 rounded-full font-medium">
                            +{cat.items.length - 6} mai multe
                          </span>
                        )}
                      </div>
                      <span className="inline-flex items-center gap-1 text-[#30d2be] font-semibold text-sm mt-4 group-hover:gap-2 transition-all">
                        Vezi Categoria <ArrowRight className="w-4 h-4" />
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white" id="despre">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Despre Noi</span>
              <h2 className="text-3xl md:text-4xl font-bold text-[#020381] mt-2 mb-6">Despre AMAprint</h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                Amaprint este o tipografie cu experiență, specializată în furnizarea serviciilor de tipar offset, digital, serigrafie și broderie. Ne mândrim cu echipa noastră de profesioniști și cu facilitățile noastre moderne de producție.
              </p>
              <p className="text-gray-600 leading-relaxed mb-6">
                Unitatea noastră de producție dispune de o gamă completă de utilaje și echipamente profesionale pentru tiparire și finisare, inclusiv mașini profesionale de tipar offset și digital, echipamente de finisare pentru tăiere, biguire, perforare, plastifiere, lăcuire UV selectivă și multe altele.
              </p>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-[#f5f7fa] rounded-xl p-4 text-center">
                  <p className="text-3xl font-extrabold text-[#020381]">9+</p>
                  <p className="text-xs text-gray-500 mt-1">Servicii</p>
                </div>
                <div className="bg-[#f5f7fa] rounded-xl p-4 text-center">
                  <p className="text-3xl font-extrabold text-[#30d2be]">5</p>
                  <p className="text-xs text-gray-500 mt-1">Zone Deservite</p>
                </div>
                <div className="bg-[#f5f7fa] rounded-xl p-4 text-center">
                  <p className="text-3xl font-extrabold text-[#020381]">100+</p>
                  <p className="text-xs text-gray-500 mt-1">Clienți</p>
                </div>
              </div>
              <Link to="/contact">
                <Button className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90 shadow-md">
                  Contactează-ne
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            <div className="relative">
              <img
                src={HERO_IMG}
                alt="Echipa și echipamentele profesionale AMAprint din Dej"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white p-6 rounded-2xl shadow-xl hidden lg:block">
                <p className="text-3xl font-extrabold">Dej</p>
                <p className="text-sm opacity-90">Jud. Cluj</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-[#020381]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Testimoniale</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2 mb-4">Ce Spun Clienții Noștri</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <Card key={t.name} className="border-0 bg-white/10 backdrop-blur-sm text-white">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#30d2be] text-[#30d2be]" />
                    ))}
                  </div>
                  <p className="text-white/80 text-sm leading-relaxed mb-4">"{t.text}"</p>
                  <p className="font-semibold text-[#30d2be]">{t.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-[#30d2be] font-semibold text-sm uppercase tracking-wider">Blog</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#020381] mt-2 mb-4">Ultimele Articole</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Link to="/blog/cum-sa-alegi-tipul-de-print-potrivit" className="group">
              <Card className="border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                <CardContent className="p-6">
                  <span className="text-xs text-gray-400">Ghiduri · 5 min</span>
                  <h3 className="font-bold text-[#020381] text-lg mt-2 mb-2 group-hover:text-[#30d2be] transition-colors">
                    Cum să Alegi Tipul de Print Potrivit pentru Afacerea Ta
                  </h3>
                  <p className="text-gray-500 text-sm">Ghid complet despre diferitele tipuri de print disponibile și cum să alegi soluția optimă.</p>
                </CardContent>
              </Card>
            </Link>
            <Link to="/blog/avantajele-gravurii-laser" className="group">
              <Card className="border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                <CardContent className="p-6">
                  <span className="text-xs text-gray-400">Tehnologie · 4 min</span>
                  <h3 className="font-bold text-[#020381] text-lg mt-2 mb-2 group-hover:text-[#30d2be] transition-colors">
                    Avantajele Gravurii Laser: De Ce Să Alegi Această Tehnologie
                  </h3>
                  <p className="text-gray-500 text-sm">Descoperă beneficiile gravurii laser pentru personalizarea cadourilor și obiectelor decorative.</p>
                </CardContent>
              </Card>
            </Link>
          </div>
          <div className="text-center mt-8">
            <Link to="/blog">
              <Button variant="outline" className="border-[#020381] text-[#020381] font-semibold hover:bg-[#020381] hover:text-white transition-all">
                Vezi Toate Articolele
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#30d2be] to-[#00d082]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ai un Proiect în Minte?</h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Contactează-ne astăzi pentru a discuta despre proiectul tău. Deservim zonele {SERVICE_AREAS.join(', ')}.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#020381] font-bold text-base px-8 hover:bg-gray-100 shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]">
                Cere Ofertă Gratuită
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="!bg-transparent border-2 border-white text-white font-bold text-base px-8 hover:!bg-white/10 transition-all">
                <Phone className="w-5 h-5 mr-2" />
                WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}