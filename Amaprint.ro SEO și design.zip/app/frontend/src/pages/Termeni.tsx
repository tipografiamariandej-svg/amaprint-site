import Layout from '@/components/Layout';

export default function Termeni() {
  return (
    <Layout>
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Termeni și Condiții</h1>
          <p className="text-white/70">Termeni și condiții generale de utilizare</p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 prose prose-lg max-w-none">
          <article className="space-y-8 text-gray-600 leading-relaxed">
            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">1. Informații Generale</h2>
              <p>
                Prezentele Termeni și Condiții Generale reglementează relația dintre AMADESIGN SRL (denumită în continuare "AMAprint", "prestator" sau "compania"), cu sediul în Str. Florilor 18, Dej, Jud. Cluj, România, și utilizatorii site-ului web amaprint.ro și clienții serviciilor noastre.
              </p>
              <p>
                Prin accesarea site-ului nostru sau utilizarea serviciilor noastre, sunteți de acord cu acești termeni și condiții.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">2. Servicii Oferite</h2>
              <p>AMAprint oferă următoarele categorii de servicii:</p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Servicii de tipografie (listare, copiere, scanare, laminare)</li>
                <li>Gravură laser pe diverse materiale</li>
                <li>Imprimare textilă și broderie</li>
                <li>Serigrafie și stampile</li>
                <li>Produse promoționale și cadouri personalizate</li>
                <li>Reclame și semnalistică vizuală</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">3. Comenzi și Plăți</h2>
              <p>
                Comenzile pot fi plasate prin telefon, email sau prin vizitarea sediului nostru. Prețurile sunt stabilite în funcție de specificațiile fiecărei comenzi. Plata se efectuează conform termenilor agreați la momentul plasării comenzii.
              </p>
              <p>
                AMAprint își rezervă dreptul de a modifica prețurile fără notificare prealabilă, cu excepția comenzilor deja confirmate.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">4. Termene de Livrare</h2>
              <p>
                Termenele de livrare sunt stabilite la momentul plasării comenzii și depind de complexitatea lucrării, volumul comenzii și disponibilitatea materialelor. AMAprint depune toate eforturile pentru respectarea termenelor agreate.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">5. Calitate și Garanții</h2>
              <p>
                AMAprint garantează calitatea lucrărilor executate conform specificațiilor agreate. În cazul în care produsul final nu corespunde specificațiilor convenite, clientul are dreptul de a solicita refacerea lucrării sau restituirea contravalorii.
              </p>
              <p>
                Reclamațiile trebuie formulate în termen de 48 de ore de la recepția produselor.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">6. Proprietate Intelectuală</h2>
              <p>
                Clientul este responsabil pentru deținerea drepturilor de proprietate intelectuală asupra materialelor furnizate pentru tipărire. AMAprint nu își asumă responsabilitatea pentru încălcarea drepturilor de autor de către client.
              </p>
              <p>
                Conținutul site-ului amaprint.ro (texte, imagini, design) este proprietatea AMADESIGN SRL și nu poate fi reprodus fără acordul scris al companiei.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">7. Limitarea Răspunderii</h2>
              <p>
                AMAprint nu este responsabilă pentru daunele indirecte sau consecințele rezultate din utilizarea sau imposibilitatea utilizării serviciilor noastre. Răspunderea maximă a companiei este limitată la valoarea comenzii respective.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">8. Protecția Datelor</h2>
              <p>
                Prelucrarea datelor cu caracter personal se realizează în conformitate cu Regulamentul (UE) 2016/679 (GDPR). Pentru detalii, consultați <a href="/gdpr" className="text-[#30d2be] hover:underline">Politica de Confidențialitate</a>.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">9. Modificări ale Termenilor</h2>
              <p>
                AMAprint își rezervă dreptul de a modifica acești termeni și condiții în orice moment. Modificările intră în vigoare la data publicării pe site. Utilizarea continuă a serviciilor noastre constituie acceptarea termenilor modificați.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">10. Legislație Aplicabilă</h2>
              <p>
                Prezentele Termeni și Condiții sunt guvernate de legislația din România. Orice litigiu va fi soluționat de instanțele competente din România.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-3">11. Contact</h2>
              <ul className="list-none space-y-1">
                <li><strong>Companie:</strong> AMADESIGN SRL</li>
                <li><strong>Brand:</strong> AMAprint</li>
                <li><strong>Adresă:</strong> <a href="https://maps.google.com/?q=amamedia+dej" target="_blank" rel="noopener noreferrer" className="text-[#30d2be] hover:underline">Str. Florilor 18, Dej, Jud. Cluj</a></li>
                <li><strong>Telefon:</strong> 0799 134 444</li>
                <li><strong>Email:</strong> contact@amaprint.ro</li>
              </ul>
            </div>

            <div className="border-t border-gray-200 pt-6 text-sm text-gray-400">
              <p>Ultima actualizare: Martie 2025</p>
              <p>AMADESIGN SRL - AMAprint</p>
            </div>
          </article>
        </div>
      </section>
    </Layout>
  );
}