import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Phone, Mail, MapPin, Clock, Send, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { SERVICE_AREAS } from '@/data/services';

const contactInfo = [
  {
    icon: Phone,
    title: 'Telefon',
    value: '0799 134 444',
    href: 'tel:0799134444',
    desc: 'Sună-ne pentru informații rapide',
  },
  {
    icon: MessageCircle,
    title: 'WhatsApp',
    value: '0799 13 44 44',
    href: 'https://wa.me/40799134444',
    desc: 'Scrie-ne pe WhatsApp oricând',
    iconColor: 'text-[#25D366]',
    external: true,
  },
  {
    icon: Mail,
    title: 'Email',
    value: 'contact@amaprint.ro',
    href: 'mailto:contact@amaprint.ro',
    desc: 'Trimite-ne un email oricând',
  },
  {
    icon: MapPin,
    title: 'Adresă',
    value: 'Str. Florilor 18, Dej, Jud. Cluj',
    href: 'https://maps.google.com/?q=amamedia+dej',
    desc: 'Vizitează-ne la sediu',
    external: true,
  },
  {
    icon: Clock,
    title: 'Program',
    value: 'Luni - Vineri: 8:00 - 17:00',
    desc: 'Weekend: Închis',
  },
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { name, email, phone, subject, message } = formData;
    const body = `Nume: ${name}\nEmail: ${email}\nTelefon: ${phone || 'Nespecificat'}\n\nMesaj:\n${message}`;
    const mailtoLink = `mailto:contact@amaprint.ro?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoLink, '_blank');
    toast.success('Se deschide aplicația de email. Trimiteți mesajul către contact@amaprint.ro.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            Contactează Tipografia AMAprint Dej
          </h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto">
            Suntem aici pentru a vă ajuta cu servicii de tipografie și print profesional în Dej și împrejurimi. Contactați-ne pentru informații sau o ofertă personalizată.
          </p>
          <div className="flex items-center justify-center gap-2 mt-4 text-white/50 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Deservim zonele: {SERVICE_AREAS.join(', ')}</span>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          {/* Contact Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-16">
            {contactInfo.map((info) => {
              const Icon = info.icon;
              return (
                <Card key={info.title} className="border-0 shadow-sm hover:shadow-lg transition-all duration-300 text-center group">
                  <CardContent className="p-5">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#30d2be]/20 to-[#00d082]/20 flex items-center justify-center mx-auto mb-3 group-hover:from-[#30d2be] group-hover:to-[#00d082] transition-all duration-300">
                      <Icon className={`w-5 h-5 group-hover:text-white transition-colors duration-300 ${info.iconColor || 'text-[#30d2be]'}`} />
                    </div>
                    <h3 className="font-bold text-[#020381] text-sm mb-1">{info.title}</h3>
                    {info.href ? (
                      <a
                        href={info.href}
                        target={info.external ? '_blank' : undefined}
                        rel="noopener noreferrer"
                        className="text-[#30d2be] font-medium hover:underline text-sm"
                      >
                        {info.value}
                      </a>
                    ) : (
                      <p className="text-gray-700 font-medium text-sm">{info.value}</p>
                    )}
                    <p className="text-gray-400 text-xs mt-1">{info.desc}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-2">Trimite-ne un Mesaj</h2>
              <p className="text-gray-500 mb-6">
                Completează formularul și te vom contacta în cel mai scurt timp. Oferim servicii de tipografie în Dej, Gherla, Beclean, Cluj și Bistrița.
              </p>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-sm font-medium text-gray-700">Nume Complet *</Label>
                    <Input id="name" name="name" value={formData.name} onChange={handleChange} required placeholder="Ion Popescu" className="mt-1.5 border-gray-200 focus:border-[#30d2be] focus:ring-[#30d2be]" />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email *</Label>
                    <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required placeholder="email@exemplu.ro" className="mt-1.5 border-gray-200 focus:border-[#30d2be] focus:ring-[#30d2be]" />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone" className="text-sm font-medium text-gray-700">Telefon</Label>
                    <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} placeholder="07xx xxx xxx" className="mt-1.5 border-gray-200 focus:border-[#30d2be] focus:ring-[#30d2be]" />
                  </div>
                  <div>
                    <Label htmlFor="subject" className="text-sm font-medium text-gray-700">Subiect *</Label>
                    <Input id="subject" name="subject" value={formData.subject} onChange={handleChange} required placeholder="Cerere ofertă cărți de vizită" className="mt-1.5 border-gray-200 focus:border-[#30d2be] focus:ring-[#30d2be]" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="message" className="text-sm font-medium text-gray-700">Mesaj *</Label>
                  <Textarea id="message" name="message" value={formData.message} onChange={handleChange} required rows={5} placeholder="Descrieți proiectul dvs. sau cererea de ofertă..." className="mt-1.5 border-gray-200 focus:border-[#30d2be] focus:ring-[#30d2be] resize-none" />
                </div>
                <Button type="submit" size="lg" className="w-full sm:w-auto bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90 shadow-md hover:shadow-lg transition-all">
                  <Send className="w-4 h-4 mr-2" />
                  Trimite Mesajul
                </Button>
              </form>
            </div>

            {/* Map */}
            <div>
              <h2 className="text-2xl font-bold text-[#020381] mb-2">Locația Noastră în Dej</h2>
              <p className="text-gray-500 mb-6">Ne găsiți pe <a href="https://maps.google.com/?q=amamedia+dej" target="_blank" rel="noopener noreferrer" className="text-[#30d2be] font-medium hover:underline">Str. Florilor 18, Dej, Jud. Cluj</a>. Deservim și zonele Gherla, Beclean, Cluj și Bistrița.</p>
              <div className="rounded-2xl overflow-hidden shadow-lg h-[400px] lg:h-[calc(100%-80px)]">
                <iframe
                  title="Locația tipografiei AMAprint pe Google Maps - Dej, Cluj"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2712.5!2d23.87!3d47.14!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDfCsDA4JzI0LjAiTiAyM8KwNTInMTIuMCJF!5e0!3m2!1sro!2sro!4v1!5m2!1sro!2sro&q=amamedia+dej"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: '350px' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>

          {/* Service Areas SEO Section */}
          <div className="mt-16 bg-[#f5f7fa] rounded-2xl p-8">
            <h2 className="text-xl font-bold text-[#020381] mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#30d2be]" />
              Zone Deservite - Tipografie și Print Profesional
            </h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              AMAprint oferă servicii complete de tipografie și print profesional în <strong>Dej</strong> și împrejurimi. Suntem tipografia de referință pentru clienții din <strong>Gherla</strong>, <strong>Beclean</strong>, <strong>Cluj-Napoca</strong> și <strong>Bistrița</strong>.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Indiferent dacă aveți nevoie de cărți de vizită, flyere, bannere, gravură laser, imprimare textilă sau orice alt serviciu de tipografie în zona Dej-Cluj-Bistrița, echipa noastră vă stă la dispoziție. Livrăm în toate localitățile din județele Cluj și Bistrița-Năsăud.
            </p>
            <div className="flex flex-wrap gap-3 mt-4">
              {SERVICE_AREAS.map((area) => (
                <span key={area} className="bg-white text-[#020381] font-semibold text-sm px-4 py-2 rounded-full shadow-sm">
                  📍 Tipografie {area}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}