import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#f5f7fa] to-white px-4">
      <div className="text-center max-w-md">
        <div className="text-8xl font-extrabold text-[#020381] mb-4">404</div>
        <h1 className="text-2xl font-bold text-[#020381] mb-3">Pagina nu a fost găsită</h1>
        <p className="text-gray-500 mb-8">
          Ne pare rău, pagina pe care o căutați nu există sau a fost mutată.
        </p>
        <Link to="/">
          <Button className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90 shadow-md">
            <Home className="w-4 h-4 mr-2" />
            Înapoi la Pagina Principală
          </Button>
        </Link>
      </div>
    </div>
  );
}