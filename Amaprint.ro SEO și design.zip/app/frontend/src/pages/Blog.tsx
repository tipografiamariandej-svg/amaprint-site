import { useParams, Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, ArrowLeft, Calendar, Clock, Tag } from 'lucide-react';
import { blogPosts } from '@/data/services';
import { useEffect } from 'react';

function BlogList() {
  useEffect(() => {
    document.title = 'Blog | AMAprint Dej - Sfaturi și Noutăți Tipografie';
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', 'Blog AMAprint Dej - Articole, ghiduri și sfaturi despre tipografie, print, gravură laser, cadouri personalizate și marketing.');
  }, []);

  return (
    <Layout>
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Blog</h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto">
            Articole, ghiduri și sfaturi despre tipografie, print și marketing pentru afacerea ta.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {blogPosts.map((post) => (
              <Link key={post.slug} to={`/blog/${post.slug}`}>
                <Card className="border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full group">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-r from-[#020381] to-[#30d2be] h-2 rounded-t-lg" />
                    <div className="p-6">
                      <div className="flex items-center gap-4 mb-3 text-sm text-gray-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {new Date(post.date).toLocaleDateString('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' })}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {post.readTime}
                        </span>
                        <span className="flex items-center gap-1">
                          <Tag className="w-3.5 h-3.5" />
                          {post.category}
                        </span>
                      </div>
                      <h2 className="text-xl font-bold text-[#020381] mb-3 group-hover:text-[#30d2be] transition-colors">
                        {post.title}
                      </h2>
                      <p className="text-gray-500 text-sm leading-relaxed mb-4">{post.excerpt}</p>
                      <span className="inline-flex items-center gap-1 text-[#30d2be] font-semibold text-sm group-hover:gap-2 transition-all">
                        Citește Articolul
                        <ArrowRight className="w-4 h-4" />
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#30d2be] to-[#00d082]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ai un Proiect în Minte?</h2>
          <p className="text-white/90 mb-8">Contactează-ne pentru o ofertă personalizată!</p>
          <Link to="/contact">
            <Button size="lg" className="bg-white text-[#020381] font-bold hover:bg-gray-100 shadow-lg">
              Contactează-ne
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}

function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = blogPosts.find((p) => p.slug === slug);

  useEffect(() => {
    if (post) {
      document.title = `${post.title} | Blog AMAprint Dej`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', post.excerpt);
    }
  }, [post]);

  if (!post) {
    return (
      <Layout>
        <div className="py-20 text-center">
          <h1 className="text-2xl font-bold text-[#020381] mb-4">Articolul nu a fost găsit</h1>
          <Link to="/blog">
            <Button className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Înapoi la Blog
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const otherPosts = blogPosts.filter((p) => p.slug !== slug).slice(0, 2);

  return (
    <Layout>
      <section className="bg-gradient-to-br from-[#020381] to-[#020381]/90 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <Link to="/blog" className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Înapoi la Blog
          </Link>
          <div className="flex items-center gap-4 mb-4 text-sm text-white/60">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {new Date(post.date).toLocaleDateString('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {post.readTime}
            </span>
            <span className="bg-[#30d2be]/20 text-[#30d2be] px-3 py-1 rounded-full text-xs font-medium">
              {post.category}
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-white">{post.title}</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <article className="prose prose-lg max-w-none">
            {post.content.split('\n\n').map((paragraph, i) => {
              if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                return <h3 key={i} className="text-xl font-bold text-[#020381] mt-8 mb-3">{paragraph.replace(/\*\*/g, '')}</h3>;
              }
              if (paragraph.startsWith('**')) {
                const parts = paragraph.split('**');
                return (
                  <p key={i} className="text-gray-600 leading-relaxed mb-4">
                    {parts.map((part, j) => (j % 2 === 1 ? <strong key={j} className="text-[#020381]">{part}</strong> : part))}
                  </p>
                );
              }
              if (paragraph.startsWith('- ')) {
                const items = paragraph.split('\n').filter(Boolean);
                return (
                  <ul key={i} className="space-y-2 mb-4 ml-4">
                    {items.map((item, j) => (
                      <li key={j} className="flex items-start gap-2 text-gray-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#30d2be] mt-2.5 shrink-0" />
                        {item.replace('- ', '')}
                      </li>
                    ))}
                  </ul>
                );
              }
              if (paragraph.match(/^\d\./)) {
                const items = paragraph.split('\n').filter(Boolean);
                return (
                  <ol key={i} className="space-y-2 mb-4 ml-4 list-decimal list-inside">
                    {items.map((item, j) => (
                      <li key={j} className="text-gray-600">{item.replace(/^\d+\.\s*/, '')}</li>
                    ))}
                  </ol>
                );
              }
              return <p key={i} className="text-gray-600 leading-relaxed mb-4">{paragraph}</p>;
            })}
          </article>

          {/* CTA */}
          <div className="mt-12 bg-gradient-to-r from-[#020381] to-[#020381]/90 rounded-2xl p-8 text-center">
            <h3 className="text-xl font-bold text-white mb-3">Ai nevoie de servicii de tipografie?</h3>
            <p className="text-white/70 mb-5">Contactează AMAprint pentru o ofertă personalizată!</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/contact">
                <Button className="bg-gradient-to-r from-[#30d2be] to-[#00d082] text-white font-semibold hover:opacity-90">
                  Cere Ofertă
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <a href="https://wa.me/40799134444" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="!bg-transparent border-[#25D366] text-[#25D366] hover:!bg-[#25D366]/10">
                  WhatsApp
                </Button>
              </a>
            </div>
          </div>

          {/* Other posts */}
          {otherPosts.length > 0 && (
            <div className="mt-12">
              <h3 className="text-xl font-bold text-[#020381] mb-6">Alte Articole</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {otherPosts.map((p) => (
                  <Link key={p.slug} to={`/blog/${p.slug}`}>
                    <Card className="border-0 shadow-sm hover:shadow-lg transition-all duration-300 h-full group">
                      <CardContent className="p-5">
                        <span className="text-xs text-gray-400">{p.category} · {p.readTime}</span>
                        <h4 className="font-bold text-[#020381] mt-1 group-hover:text-[#30d2be] transition-colors">{p.title}</h4>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}

export { BlogList, BlogPost };
export default BlogList;