# AMAprint - Redesign Modern & SEO Optimizat

## Design Guidelines

### Design References
- **Vistaprint.com**: Clean printing service layout
- **MOO.com**: Modern print company with bold visuals
- **Style**: Modern Professional + Clean + Print Industry

### Color Palette
- Primary: #020381 (Albastru închis - brand)
- Accent: #30d2be (Verde-turcoaz - CTA/highlights)
- Accent Gradient: #30d2be → #00d082
- Background: #FFFFFF (White)
- Background Alt: #f5f7fa (Gri deschis)
- Text Primary: #1a1a2e (Near black)
- Text Secondary: #54595f (Gri)
- Dark: #0a0a1a (Footer/dark sections)

### Typography
- Headings: Inter font-weight 700/600
- Body: Inter font-weight 400 (16px)
- Navigation: Inter font-weight 600 (16px)

### Key Component Styles
- **Buttons Primary**: Gradient #30d2be→#00d082, white text, 8px rounded, hover: scale 1.02
- **Buttons Secondary**: Border #020381, text #020381, hover: fill #020381
- **Cards**: White bg, subtle shadow, 12px rounded, hover: lift 4px
- **Sections**: Alternating white/#f5f7fa backgrounds, 80px vertical padding

### Layout & Spacing
- Hero: Full viewport with gradient overlay
- Services grid: 3 columns desktop, 2 tablet, 1 mobile
- Products grid: 2 columns desktop, 1 mobile
- Section padding: 80px vertical, max-w-7xl container

### Images to Generate
1. **hero-printing-workshop.jpg** - Modern printing workshop with professional printing machines, vibrant colors, clean environment (photorealistic, 1024x576)
2. **services-laser-engraving.jpg** - Close-up of laser engraving machine working on wood material with precise details (photorealistic, 1024x576)
3. **services-textile-printing.jpg** - Textile printing process showing colorful t-shirts being printed on professional equipment (photorealistic, 1024x576)
4. **products-promotional-items.jpg** - Collection of promotional items including pens, mugs, calendars, business cards arranged professionally on a desk (photorealistic, 1024x576)

---

## Development Tasks

### Files to create (max 8):
1. **index.html** - Update meta tags, SEO, schema markup
2. **src/pages/Index.tsx** - Homepage (hero, services preview, products preview, about, CTA)
3. **src/pages/Servicii.tsx** - Services page with all 9 services detailed
4. **src/pages/Produse.tsx** - Products page with 4 categories
5. **src/pages/Contact.tsx** - Contact page with form, map, info
6. **src/pages/GDPR.tsx** - GDPR policy page
7. **src/pages/Termeni.tsx** - Terms and conditions page
8. **src/App.tsx** - Router with all pages + shared layout (Navbar/Footer as components within)

### SEO Requirements per page:
- Unique title, meta description
- Schema markup LocalBusiness in index.html
- Semantic HTML throughout
- Proper heading hierarchy
- Open Graph tags